# Router Configuration Examples

This directory contains generated QoS configuration files for different router types.

## Files

- **openwrt_qos.sh**: OpenWrt SQM (Smart Queue Management) configuration
- **ddwrt_qos.sh**: DD-WRT QoS configuration script
- **generic_qos.json**: Generic JSON configuration for routers supporting JSON import

## Usage Instructions

### Before Applying Configuration

1. **Backup your current router configuration**
2. **Note your current bandwidth**: Update bandwidth values in the config files to match your connection
3. **Review the configuration**: Ensure port numbers and rules match your needs

### OpenWrt

1. SSH into your router
2. Install SQM packages:
   ```bash
   opkg update
   opkg install sqm-scripts luci-app-sqm
   ```
3. Copy the script content and execute on the router
4. Or configure via LuCI: Network → SQM QoS

### DD-WRT

1. Access router web interface
2. Go to Administration → Commands
3. Paste the script content
4. Click "Save Startup"
5. Reboot the router

### Generic Router

1. Access router web interface
2. Look for QoS/Traffic Shaping settings
3. Import or manually configure using the JSON file as reference
4. Adjust bandwidth values to match your connection

## Customization

### Adjusting Bandwidth

Edit the bandwidth values in the configuration files:
- Priority slice: 50% of total bandwidth
- Normal slice: 35% of total bandwidth
- Background slice: 15% of total bandwidth

### Adding Applications

To add custom application mappings, modify the configuration or use the application mapper in the main tool.

## Important Notes

- These are template configurations - customize for your specific router model
- Test in a controlled environment before production use
- Some routers may require different command syntax
- Bandwidth values are in Mbps - adjust according to your connection speed
- Port-based rules may need adjustment based on your applications

## Troubleshooting

- If configuration doesn't apply: Check router firmware version compatibility
- If QoS doesn't work: Verify router supports QoS/traffic shaping
- If performance degrades: Revert to backup configuration

