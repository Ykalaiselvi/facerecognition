# OpenWrt SQM Configuration for Network Slicing
# Generated automatically for QoS setup

# Install required packages:
# opkg update
# opkg install sqm-scripts luci-app-sqm

# Configure SQM on WAN interface
uci set sqm.@queue[0].interface='wan'
uci set sqm.@queue[0].enabled='1'

# Priority Slice Configuration
uci set sqm.@queue[0].download=50
uci set sqm.@queue[0].upload=50

# Apply configuration
uci commit sqm
/etc/init.d/sqm restart

# Additional QoS rules using tc (traffic control)
# Priority slice - Online classes and video calls
tc qdisc add dev eth0 root handle 1: htb default 30
tc class add dev eth0 parent 1: classid 1:1 htb rate 100mbit

# Priority class (50% bandwidth)
tc class add dev eth0 parent 1:1 classid 1:10 htb rate 50mbit ceil 50mbit prio 1
tc filter add dev eth0 protocol ip parent 1:0 prio 1 u32 match ip dport 443 0xffff flowid 1:10
tc filter add dev eth0 protocol ip parent 1:0 prio 1 u32 match ip dport 8801 0xffff flowid 1:10

# Normal class (35% bandwidth)
tc class add dev eth0 parent 1:1 classid 1:20 htb rate 35mbit ceil 35mbit prio 2
tc filter add dev eth0 protocol ip parent 1:0 prio 2 u32 match ip dport 80 0xffff flowid 1:20

# Background class (15% bandwidth)
tc class add dev eth0 parent 1:1 classid 1:30 htb rate 15mbit ceil 15mbit prio 3