"""
Traffic Classifier
Classifies network traffic into appropriate slices based on various criteria.
"""

import socket
from typing import Optional, Dict
from network_slicing.models import TrafficFlow, SliceType
from config_generator.application_mapper import ApplicationMapper


class TrafficClassifier:
    """Classifies network traffic into network slices."""
    
    def __init__(self):
        """Initialize the traffic classifier."""
        self.mapper = ApplicationMapper()
        self.port_cache: Dict[int, SliceType] = {}
    
    def classify_by_port(self, port: int) -> SliceType:
        """
        Classify traffic based on port number.
        
        Args:
            port: Network port number
            
        Returns:
            SliceType for the port
        """
        if port in self.port_cache:
            return self.port_cache[port]
        
        slice_type = self.mapper.get_slice_for_port(port)
        self.port_cache[port] = slice_type
        return slice_type
    
    def classify_by_application(self, app_name: str) -> SliceType:
        """
        Classify traffic based on application name.
        
        Args:
            app_name: Application name or process name
            
        Returns:
            SliceType for the application
        """
        return self.mapper.get_slice_for_application(app_name)
    
    def classify_flow(self, flow: TrafficFlow) -> SliceType:
        """
        Classify a traffic flow using multiple criteria.
        
        Args:
            flow: TrafficFlow object to classify
            
        Returns:
            SliceType for the flow
        """
        return self.mapper.classify_traffic_flow(flow)
    
    def get_service_name(self, port: int, protocol: str = 'tcp') -> Optional[str]:
        """
        Get service name for a port (if available).
        
        Args:
            port: Port number
            protocol: Protocol (tcp/udp)
            
        Returns:
            Service name or None
        """
        try:
            service_name = socket.getservbyport(port, protocol)
            return service_name
        except (OSError, socket.error):
            return None
    
    def is_known_video_conferencing_port(self, port: int) -> bool:
        """
        Check if a port is commonly used for video conferencing.
        
        Args:
            port: Port number to check
            
        Returns:
            True if port is used for video conferencing
        """
        video_ports = {443, 8801, 8802, 8803, 8804, 8805, 8806, 8807, 8808, 8809, 8810, 3478, 3479}
        return port in video_ports
    
    def is_known_streaming_port(self, port: int) -> bool:
        """
        Check if a port is commonly used for streaming.
        
        Args:
            port: Port number to check
            
        Returns:
            True if port is used for streaming
        """
        streaming_ports = {80, 443, 1935, 554}
        return port in streaming_ports

