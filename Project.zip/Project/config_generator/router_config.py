"""
Router Configuration Generator
Generates QoS configuration files for various router types.
"""

import json
from typing import Dict, Optional
from pathlib import Path
from network_slicing.config import NetworkSlicingConfig


class RouterConfigGenerator:
    """Generates router configuration files for network slicing."""
    
    def __init__(self, total_bandwidth_mbps: float = 100.0):
        """
        Initialize the router config generator.
        
        Args:
            total_bandwidth_mbps: Total available bandwidth in Mbps
        """
        self.total_bandwidth = total_bandwidth_mbps
        self.config = NetworkSlicingConfig()
    
    def generate_openwrt_config(self, output_path: str) -> str:
        """
        Generate OpenWrt SQM (Smart Queue Management) configuration.
        
        Args:
            output_path: Path to save the configuration file
            
        Returns:
            Generated configuration content
        """
        slices = self.config.get_all_slices()
        
        config_lines = [
            "# OpenWrt SQM Configuration for Network Slicing",
            "# Generated automatically for QoS setup",
            "",
            "# Install required packages:",
            "# opkg update",
            "# opkg install sqm-scripts luci-app-sqm",
            "",
            "# Configure SQM on WAN interface",
            "uci set sqm.@queue[0].interface='wan'",
            "uci set sqm.@queue[0].enabled='1'",
            "",
            "# Priority Slice Configuration",
            f"uci set sqm.@queue[0].download={int(self.total_bandwidth * slices['priority'].bandwidth_percent / 100)}",
            f"uci set sqm.@queue[0].upload={int(self.total_bandwidth * slices['priority'].bandwidth_percent / 100)}",
            "",
            "# Apply configuration",
            "uci commit sqm",
            "/etc/init.d/sqm restart",
            "",
            "# Additional QoS rules using tc (traffic control)",
            "# Priority slice - Online classes and video calls",
            f"tc qdisc add dev eth0 root handle 1: htb default 30",
            f"tc class add dev eth0 parent 1: classid 1:1 htb rate {int(self.total_bandwidth)}mbit",
            "",
            f"# Priority class (50% bandwidth)",
            f"tc class add dev eth0 parent 1:1 classid 1:10 htb rate {int(self.total_bandwidth * 0.5)}mbit ceil {int(self.total_bandwidth * 0.5)}mbit prio 1",
            f"tc filter add dev eth0 protocol ip parent 1:0 prio 1 u32 match ip dport 443 0xffff flowid 1:10",
            f"tc filter add dev eth0 protocol ip parent 1:0 prio 1 u32 match ip dport 8801 0xffff flowid 1:10",
            "",
            f"# Normal class (35% bandwidth)",
            f"tc class add dev eth0 parent 1:1 classid 1:20 htb rate {int(self.total_bandwidth * 0.35)}mbit ceil {int(self.total_bandwidth * 0.35)}mbit prio 2",
            f"tc filter add dev eth0 protocol ip parent 1:0 prio 2 u32 match ip dport 80 0xffff flowid 1:20",
            "",
            f"# Background class (15% bandwidth)",
            f"tc class add dev eth0 parent 1:1 classid 1:30 htb rate {int(self.total_bandwidth * 0.15)}mbit ceil {int(self.total_bandwidth * 0.15)}mbit prio 3",
        ]
        
        config_content = "\n".join(config_lines)
        
        # Save to file
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            f.write(config_content)
        
        return config_content
    
    def generate_json_config(self, output_path: str) -> str:
        """
        Generate generic JSON configuration for routers.
        
        Args:
            output_path: Path to save the configuration file
            
        Returns:
            Generated configuration content
        """
        slices = self.config.get_all_slices()
        
        config = {
            "network_slicing": {
                "total_bandwidth_mbps": self.total_bandwidth,
                "slices": {}
            },
            "qos_rules": []
        }
        
        # Add slice configurations
        for slice_key, slice_config in slices.items():
            config["network_slicing"]["slices"][slice_key] = {
                "name": slice_config.name,
                "priority": slice_config.priority,
                "bandwidth_percent": slice_config.bandwidth_percent,
                "bandwidth_mbps": self.total_bandwidth * slice_config.bandwidth_percent / 100,
                "latency_target_ms": slice_config.latency_target_ms,
                "description": slice_config.description
            }
        
        # Add QoS rules based on ports
        priority_ports = list(self.config.PORT_MAPPING['priority_ports'])
        normal_ports = list(self.config.PORT_MAPPING['normal_ports'])
        background_ports = list(self.config.PORT_MAPPING['background_ports'])
        
        config["qos_rules"].append({
            "rule_id": "priority_ports",
            "slice": "priority",
            "type": "port",
            "ports": priority_ports[:10],  # Limit to first 10 for readability
            "priority": 3
        })
        
        config["qos_rules"].append({
            "rule_id": "normal_ports",
            "slice": "normal",
            "type": "port",
            "ports": normal_ports,
            "priority": 2
        })
        
        config["qos_rules"].append({
            "rule_id": "background_ports",
            "slice": "background",
            "type": "port",
            "ports": background_ports,
            "priority": 1
        })
        
        # Add application mappings
        config["application_mapping"] = {}
        for app, slice_name in self.config.APPLICATION_MAPPING.items():
            if slice_name not in config["application_mapping"]:
                config["application_mapping"][slice_name] = []
            config["application_mapping"][slice_name].append(app)
        
        config_content = json.dumps(config, indent=2)
        
        # Save to file
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            f.write(config_content)
        
        return config_content
    
    def generate_ddwrt_config(self, output_path: str) -> str:
        """
        Generate DD-WRT QoS configuration script.
        
        Args:
            output_path: Path to save the configuration file
            
        Returns:
            Generated configuration content
        """
        slices = self.config.get_all_slices()
        
        config_lines = [
            "# DD-WRT QoS Configuration for Network Slicing",
            "# Apply via: Administration -> Commands -> Run Commands",
            "",
            "# Enable QoS",
            "nvram set qos_enable=1",
            "nvram set qos_classnames=\"Priority Normal Background\"",
            "",
            "# Set total bandwidth",
            f"nvram set qos_ibw={int(self.total_bandwidth)}",
            f"nvram set qos_obw={int(self.total_bandwidth)}",
            "",
            "# Priority Slice (50% bandwidth)",
            f"nvram set qos_orules=\"<Priority> <443> <0> <{int(self.total_bandwidth * 0.5)}> <0> <0> <0> <0>\"",
            "",
            "# Normal Slice (35% bandwidth)",
            f"nvram set qos_orules=\"$qos_orules <Normal> <80> <0> <{int(self.total_bandwidth * 0.35)}> <0> <0> <0> <0>\"",
            "",
            "# Background Slice (15% bandwidth)",
            f"nvram set qos_orules=\"$qos_orules <Background> <21> <0> <{int(self.total_bandwidth * 0.15)}> <0> <0> <0> <0>\"",
            "",
            "# Commit and restart QoS",
            "nvram commit",
            "stopservice qos",
            "startservice qos",
        ]
        
        config_content = "\n".join(config_lines)
        
        # Save to file
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            f.write(config_content)
        
        return config_content
    
    def generate_all_configs(self, output_dir: str = "config_examples"):
        """
        Generate all configuration types.
        
        Args:
            output_dir: Directory to save all configurations
        """
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        self.generate_openwrt_config(f"{output_dir}/openwrt_qos.sh")
        self.generate_json_config(f"{output_dir}/generic_qos.json")
        self.generate_ddwrt_config(f"{output_dir}/ddwrt_qos.sh")
        
        print(f"Generated configurations saved to {output_dir}/")

