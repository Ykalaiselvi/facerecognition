// Chart instances
let latencyChart = null;
let jitterChart = null;
let throughputChart = null;
let sliceComparisonChart = null;

// Data storage
let metricsData = {
    timestamps: [],
    latency: [],
    jitter: [],
    throughput: []
};

let sliceData = {};

// Chart colors
const colors = {
    latency: 'rgba(102, 126, 234, 1)',
    jitter: 'rgba(255, 159, 64, 1)',
    throughput: 'rgba(40, 167, 69, 1)',
    priority: 'rgba(17, 153, 142, 1)',
    normal: 'rgba(102, 126, 234, 1)',
    background: 'rgba(245, 87, 108, 1)'
};

// Initialize all charts
function initializeCharts() {
    initializeLatencyChart();
    initializeJitterChart();
    initializeThroughputChart();
    initializeSliceComparisonChart();
    startDataUpdates();
}

function initializeLatencyChart() {
    const ctx = document.getElementById('latencyChart').getContext('2d');
    latencyChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Latency (ms)',
                data: [],
                borderColor: colors.latency,
                backgroundColor: colors.latency.replace('1)', '0.1)'),
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Latency (ms)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Time'
                    }
                }
            }
        }
    });
}

function initializeJitterChart() {
    const ctx = document.getElementById('jitterChart').getContext('2d');
    jitterChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Jitter (ms)',
                data: [],
                borderColor: colors.jitter,
                backgroundColor: colors.jitter.replace('1)', '0.1)'),
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Jitter (ms)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Time'
                    }
                }
            }
        }
    });
}

function initializeThroughputChart() {
    const ctx = document.getElementById('throughputChart').getContext('2d');
    throughputChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Throughput (Mbps)',
                data: [],
                borderColor: colors.throughput,
                backgroundColor: colors.throughput.replace('1)', '0.1)'),
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Throughput (Mbps)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Time'
                    }
                }
            }
        }
    });
}

function initializeSliceComparisonChart() {
    const ctx = document.getElementById('sliceComparisonChart').getContext('2d');
    sliceComparisonChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Bandwidth Usage (Mbps)',
                data: [],
                backgroundColor: [
                    colors.priority,
                    colors.normal,
                    colors.background
                ],
                borderColor: [
                    colors.priority,
                    colors.normal,
                    colors.background
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Bandwidth Usage (Mbps)'
                    }
                }
            }
        }
    });
}

// Update charts with new data
function updateCharts() {
    // Update latency chart
    if (latencyChart && metricsData.latency.length > 0) {
        const maxPoints = 50;
        const startIdx = Math.max(0, metricsData.latency.length - maxPoints);
        
        latencyChart.data.labels = metricsData.timestamps.slice(startIdx).map(ts => {
            const date = new Date(ts);
            return date.toLocaleTimeString();
        });
        latencyChart.data.datasets[0].data = metricsData.latency.slice(startIdx);
        latencyChart.update('none');
    }

    // Update jitter chart
    if (jitterChart && metricsData.jitter.length > 0) {
        const maxPoints = 50;
        const startIdx = Math.max(0, metricsData.jitter.length - maxPoints);
        
        jitterChart.data.labels = metricsData.timestamps.slice(startIdx).map(ts => {
            const date = new Date(ts);
            return date.toLocaleTimeString();
        });
        jitterChart.data.datasets[0].data = metricsData.jitter.slice(startIdx);
        jitterChart.update('none');
    }

    // Update throughput chart
    if (throughputChart && metricsData.throughput.length > 0) {
        const maxPoints = 50;
        const startIdx = Math.max(0, metricsData.throughput.length - maxPoints);
        
        throughputChart.data.labels = metricsData.timestamps.slice(startIdx).map(ts => {
            const date = new Date(ts);
            return date.toLocaleTimeString();
        });
        throughputChart.data.datasets[0].data = metricsData.throughput.slice(startIdx);
        throughputChart.update('none');
    }

    // Update slice comparison chart
    if (sliceComparisonChart && Object.keys(sliceData).length > 0) {
        const labels = Object.keys(sliceData);
        const data = labels.map(label => sliceData[label].current_bandwidth_usage || 0);
        
        sliceComparisonChart.data.labels = labels;
        sliceComparisonChart.data.datasets[0].data = data;
        sliceComparisonChart.update('none');
    }
}

// Fetch current metrics
async function fetchCurrentMetrics() {
    try {
        const response = await fetch('/api/metrics/current');
        const data = await response.json();
        
        // Update metric cards
        document.getElementById('latencyValue').textContent = data.latency_ms.toFixed(2);
        document.getElementById('jitterValue').textContent = data.jitter_ms.toFixed(2);
        document.getElementById('throughputValue').textContent = data.throughput_mbps.toFixed(2);
        
        // Add to metrics data
        if (data.timestamp) {
            metricsData.timestamps.push(data.timestamp);
            metricsData.latency.push(data.latency_ms);
            metricsData.jitter.push(data.jitter_ms);
            metricsData.throughput.push(data.throughput_mbps);
            
            // Keep only last 100 points
            if (metricsData.timestamps.length > 100) {
                metricsData.timestamps.shift();
                metricsData.latency.shift();
                metricsData.jitter.shift();
                metricsData.throughput.shift();
            }
        }
        
        updateCharts();
    } catch (error) {
        console.error('Error fetching metrics:', error);
    }
}

// Fetch slice statistics
async function fetchSliceStatistics() {
    try {
        const response = await fetch('/api/slices/statistics');
        sliceData = await response.json();
        
        updateSliceCards();
        updateCharts();
    } catch (error) {
        console.error('Error fetching slice statistics:', error);
    }
}

// Update slice cards
function updateSliceCards() {
    const slicesGrid = document.getElementById('slicesGrid');
    slicesGrid.innerHTML = '';
    
    // Get slice configuration
    fetch('/api/slices/config')
        .then(res => res.json())
        .then(config => {
            for (const [sliceKey, sliceInfo] of Object.entries(sliceData)) {
                const sliceConfig = Object.values(config).find(s => s.name === sliceInfo.name || sliceKey === s.name);
                
                const card = document.createElement('div');
                card.className = `slice-card ${sliceKey.toLowerCase()}`;
                
                const usagePercent = sliceConfig ? 
                    (sliceInfo.current_bandwidth_usage / (sliceConfig.bandwidth_percent * 1.0)) * 100 : 0;
                
                card.innerHTML = `
                    <h3>${sliceInfo.name || sliceKey}</h3>
                    <div class="slice-info">
                        <div class="slice-info-item">
                            <span class="slice-info-label">Active Flows:</span>
                            <span class="slice-info-value">${sliceInfo.active_flows || 0}</span>
                        </div>
                        <div class="slice-info-item">
                            <span class="slice-info-label">Bandwidth Allocation:</span>
                            <span class="slice-info-value">${sliceConfig?.bandwidth_percent || 0}%</span>
                        </div>
                        <div class="slice-info-item">
                            <span class="slice-info-label">Current Usage:</span>
                            <span class="slice-info-value">${(sliceInfo.current_bandwidth_usage || 0).toFixed(2)} Mbps</span>
                        </div>
                        <div class="slice-info-item">
                            <span class="slice-info-label">Total Bytes:</span>
                            <span class="slice-info-value">${formatBytes(sliceInfo.total_bytes || 0)}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${Math.min(usagePercent, 100)}%"></div>
                        </div>
                    </div>
                `;
                
                slicesGrid.appendChild(card);
            }
        })
        .catch(error => console.error('Error fetching slice config:', error));
}

// Format bytes
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// Update status
async function updateStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        document.getElementById('monitoringStatus').textContent = data.monitoring_active ? 'Active' : 'Inactive';
        document.getElementById('simulationStatus').textContent = data.simulation_active ? 'Active' : 'Inactive';
        document.getElementById('dataPoints').textContent = data.metrics_count || 0;
        
        // Update button visibility
        document.getElementById('startMonitoring').style.display = data.monitoring_active ? 'none' : 'inline-block';
        document.getElementById('stopMonitoring').style.display = data.monitoring_active ? 'inline-block' : 'none';
        document.getElementById('startSimulation').style.display = data.simulation_active ? 'none' : 'inline-block';
        document.getElementById('stopSimulation').style.display = data.simulation_active ? 'inline-block' : 'none';
    } catch (error) {
        console.error('Error fetching status:', error);
    }
}

// Start data updates
function startDataUpdates() {
    setInterval(() => {
        fetchCurrentMetrics();
        fetchSliceStatistics();
    }, 2000); // Update every 2 seconds
}

// Button event listeners
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('startMonitoring').addEventListener('click', async function() {
        try {
            const response = await fetch('/api/monitoring/start', { method: 'POST' });
            const data = await response.json();
            alert(data.message);
            updateStatus();
        } catch (error) {
            alert('Error starting monitoring: ' + error.message);
        }
    });
    
    document.getElementById('stopMonitoring').addEventListener('click', async function() {
        try {
            const response = await fetch('/api/monitoring/stop', { method: 'POST' });
            const data = await response.json();
            alert(data.message);
            updateStatus();
        } catch (error) {
            alert('Error stopping monitoring: ' + error.message);
        }
    });
    
    document.getElementById('startSimulation').addEventListener('click', async function() {
        const bandwidth = prompt('Enter total bandwidth (Mbps):', '100');
        const flows = prompt('Enter number of traffic flows:', '10');
        
        if (bandwidth && flows) {
            try {
                const response = await fetch('/api/simulation/start', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        bandwidth: parseFloat(bandwidth),
                        flows: parseInt(flows)
                    })
                });
                const data = await response.json();
                if (data.error) {
                    alert('Error: ' + data.error);
                } else {
                    alert(data.message);
                    updateStatus();
                }
            } catch (error) {
                alert('Error starting simulation: ' + error.message);
            }
        }
    });
    
    document.getElementById('stopSimulation').addEventListener('click', async function() {
        try {
            const response = await fetch('/api/simulation/stop', { method: 'POST' });
            const data = await response.json();
            alert(data.message);
            updateStatus();
        } catch (error) {
            alert('Error stopping simulation: ' + error.message);
        }
    });
});

