"""
Chart Generator
Generates charts for network metrics visualization.
"""

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from typing import List, Optional
from datetime import datetime
from network_slicing.models import NetworkMetrics


class ChartGenerator:
    """Generates charts for network metrics."""
    
    def __init__(self, figsize=(12, 6)):
        """
        Initialize the chart generator.
        
        Args:
            figsize: Figure size tuple (width, height)
        """
        self.figsize = figsize
        # Try to use a nice style, fallback to default
        try:
            if 'seaborn-v0_8-darkgrid' in plt.style.available:
                plt.style.use('seaborn-v0_8-darkgrid')
            elif 'seaborn-darkgrid' in plt.style.available:
                plt.style.use('seaborn-darkgrid')
            else:
                plt.style.use('default')
        except:
            plt.style.use('default')
    
    def plot_latency(self, metrics_list: List[NetworkMetrics], title: str = "Network Latency Over Time", 
                     save_path: Optional[str] = None):
        """
        Plot latency over time.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            title: Chart title
            save_path: Optional path to save the chart
        """
        if not metrics_list:
            return
        
        timestamps = [m.timestamp for m in metrics_list]
        latencies = [m.latency_ms for m in metrics_list]
        
        fig, ax = plt.subplots(figsize=self.figsize)
        ax.plot(timestamps, latencies, marker='o', linestyle='-', linewidth=2, markersize=4)
        ax.set_xlabel('Time')
        ax.set_ylabel('Latency (ms)')
        ax.set_title(title)
        ax.grid(True, alpha=0.3)
        
        # Format x-axis dates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        
        plt.close()
    
    def plot_jitter(self, metrics_list: List[NetworkMetrics], title: str = "Network Jitter Over Time",
                    save_path: Optional[str] = None):
        """
        Plot jitter over time.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            title: Chart title
            save_path: Optional path to save the chart
        """
        if not metrics_list:
            return
        
        timestamps = [m.timestamp for m in metrics_list]
        jitters = [m.jitter_ms for m in metrics_list]
        
        fig, ax = plt.subplots(figsize=self.figsize)
        ax.plot(timestamps, jitters, marker='s', linestyle='-', linewidth=2, markersize=4, color='orange')
        ax.set_xlabel('Time')
        ax.set_ylabel('Jitter (ms)')
        ax.set_title(title)
        ax.grid(True, alpha=0.3)
        
        # Format x-axis dates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        
        plt.close()
    
    def plot_throughput(self, metrics_list: List[NetworkMetrics], title: str = "Network Throughput Over Time",
                        save_path: Optional[str] = None):
        """
        Plot throughput over time.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            title: Chart title
            save_path: Optional path to save the chart
        """
        if not metrics_list:
            return
        
        timestamps = [m.timestamp for m in metrics_list]
        throughputs = [m.throughput_mbps for m in metrics_list]
        
        fig, ax = plt.subplots(figsize=self.figsize)
        ax.plot(timestamps, throughputs, marker='^', linestyle='-', linewidth=2, markersize=4, color='green')
        ax.set_xlabel('Time')
        ax.set_ylabel('Throughput (Mbps)')
        ax.set_title(title)
        ax.grid(True, alpha=0.3)
        
        # Format x-axis dates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        
        plt.close()
    
    def plot_all_metrics(self, metrics_list: List[NetworkMetrics], title: str = "Network Metrics Overview",
                         save_path: Optional[str] = None):
        """
        Plot all metrics in subplots.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            title: Chart title
            save_path: Optional path to save the chart
        """
        if not metrics_list:
            return
        
        timestamps = [m.timestamp for m in metrics_list]
        latencies = [m.latency_ms for m in metrics_list]
        jitters = [m.jitter_ms for m in metrics_list]
        throughputs = [m.throughput_mbps for m in metrics_list]
        
        fig, axes = plt.subplots(3, 1, figsize=(12, 10))
        fig.suptitle(title, fontsize=14, fontweight='bold')
        
        # Latency
        axes[0].plot(timestamps, latencies, marker='o', linestyle='-', linewidth=2, markersize=3, color='blue')
        axes[0].set_ylabel('Latency (ms)')
        axes[0].set_title('Latency Over Time')
        axes[0].grid(True, alpha=0.3)
        axes[0].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        
        # Jitter
        axes[1].plot(timestamps, jitters, marker='s', linestyle='-', linewidth=2, markersize=3, color='orange')
        axes[1].set_ylabel('Jitter (ms)')
        axes[1].set_title('Jitter Over Time')
        axes[1].grid(True, alpha=0.3)
        axes[1].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        
        # Throughput
        axes[2].plot(timestamps, throughputs, marker='^', linestyle='-', linewidth=2, markersize=3, color='green')
        axes[2].set_ylabel('Throughput (Mbps)')
        axes[2].set_xlabel('Time')
        axes[2].set_title('Throughput Over Time')
        axes[2].grid(True, alpha=0.3)
        axes[2].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        
        plt.xticks(rotation=45)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        
        plt.close()
    
    def plot_slice_comparison(self, metrics_list: List[NetworkMetrics], metric_name: str = "latency_ms",
                              title: Optional[str] = None, save_path: Optional[str] = None):
        """
        Plot metric comparison across slices.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            metric_name: Metric to compare ('latency_ms', 'jitter_ms', 'throughput_mbps')
            title: Chart title (None = auto-generate)
            save_path: Optional path to save the chart
        """
        if not metrics_list:
            return
        
        # Extract slice metrics
        slice_data = {}
        for metrics in metrics_list:
            for slice_name, slice_metrics in metrics.slice_metrics.items():
                if slice_name not in slice_data:
                    slice_data[slice_name] = []
                
                value = slice_metrics.get(metric_name)
                if value is not None:
                    slice_data[slice_name].append(value)
        
        if not slice_data:
            return
        
        # Calculate averages
        slice_averages = {name: sum(values) / len(values) if values else 0.0 
                         for name, values in slice_data.items()}
        
        # Create bar chart
        fig, ax = plt.subplots(figsize=self.figsize)
        slices = list(slice_averages.keys())
        values = list(slice_averages.values())
        
        colors = ['#2ecc71', '#3498db', '#e74c3c']  # Green, Blue, Red
        bars = ax.bar(slices, values, color=colors[:len(slices)], alpha=0.7, edgecolor='black', linewidth=1.5)
        
        # Add value labels on bars
        for bar, value in zip(bars, values):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{value:.2f}',
                   ha='center', va='bottom', fontweight='bold')
        
        metric_label = metric_name.replace('_', ' ').title()
        ax.set_ylabel(metric_label)
        ax.set_xlabel('Network Slice')
        ax.set_title(title or f'{metric_label} Comparison Across Slices')
        ax.grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        
        plt.close()

