"""
Traffic Generator
Generates synthetic traffic patterns for simulation.
"""

import random
import time
from typing import Dict, List, Optional
from datetime import datetime
from network_slicing.models import TrafficFlow, SliceType
from network_slicing.config import NetworkSlicingConfig


class TrafficGenerator:
    """Generates synthetic network traffic for simulation."""
    
    def __init__(self):
        """Initialize the traffic generator."""
        self.config = NetworkSlicingConfig()
        self.flow_counter = 0
    
    def generate_flow_id(self) -> str:
        """Generate a unique flow ID."""
        self.flow_counter += 1
        return f"flow_{self.flow_counter}_{int(time.time())}"
    
    def generate_priority_flow(self, duration_seconds: float = 60.0) -> TrafficFlow:
        """
        Generate a priority slice traffic flow (video conferencing).
        
        Args:
            duration_seconds: Expected duration of the flow
            
        Returns:
            TrafficFlow object
        """
        # Zoom-like traffic: high bandwidth, low latency requirement
        flow = TrafficFlow(
            flow_id=self.generate_flow_id(),
            slice_type=SliceType.PRIORITY,
            source_ip=f"192.168.1.{random.randint(10, 50)}",
            dest_ip=f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}",
            source_port=random.randint(50000, 60000),
            dest_port=random.choice([443, 8801, 8802, 8803]),
            protocol="TCP",
            application_name="zoom.exe"
        )
        
        # Simulate video call traffic: ~2-4 Mbps
        bytes_per_second = random.randint(250_000, 500_000)  # 2-4 Mbps
        flow.bytes_sent = int(bytes_per_second * duration_seconds * 0.6)  # More upload
        flow.bytes_received = int(bytes_per_second * duration_seconds * 0.4)  # Less download
        flow.packets_sent = flow.bytes_sent // 1500  # Assume ~1500 byte packets
        flow.packets_received = flow.bytes_received // 1500
        
        return flow
    
    def generate_normal_flow(self, duration_seconds: float = 300.0) -> TrafficFlow:
        """
        Generate a normal slice traffic flow (web browsing/streaming).
        
        Args:
            duration_seconds: Expected duration of the flow
            
        Returns:
            TrafficFlow object
        """
        # YouTube/streaming traffic: variable bandwidth
        flow = TrafficFlow(
            flow_id=self.generate_flow_id(),
            slice_type=SliceType.NORMAL,
            source_ip=f"192.168.1.{random.randint(10, 50)}",
            dest_ip=f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}",
            source_port=random.randint(50000, 60000),
            dest_port=random.choice([80, 443]),
            protocol="TCP",
            application_name=random.choice(["chrome.exe", "firefox.exe", "msedge.exe"])
        )
        
        # Streaming: ~1-5 Mbps depending on quality
        bytes_per_second = random.randint(125_000, 625_000)
        flow.bytes_sent = int(bytes_per_second * duration_seconds * 0.1)  # Mostly download
        flow.bytes_received = int(bytes_per_second * duration_seconds * 0.9)
        flow.packets_sent = flow.bytes_sent // 1500
        flow.packets_received = flow.bytes_received // 1500
        
        return flow
    
    def generate_background_flow(self, duration_seconds: float = 600.0) -> TrafficFlow:
        """
        Generate a background slice traffic flow (downloads/updates).
        
        Args:
            duration_seconds: Expected duration of the flow
            
        Returns:
            TrafficFlow object
        """
        # File download/update traffic: high bandwidth, not time-sensitive
        flow = TrafficFlow(
            flow_id=self.generate_flow_id(),
            slice_type=SliceType.BACKGROUND,
            source_ip=f"192.168.1.{random.randint(10, 50)}",
            dest_ip=f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}",
            source_port=random.randint(50000, 60000),
            dest_port=random.choice([80, 443, 21]),
            protocol="TCP",
            application_name=random.choice(["wuauclt.exe", "steam.exe", "chrome.exe"])
        )
        
        # Downloads: can use full available bandwidth
        bytes_per_second = random.randint(500_000, 2_000_000)  # 4-16 Mbps
        flow.bytes_sent = int(bytes_per_second * duration_seconds * 0.05)  # Minimal upload
        flow.bytes_received = int(bytes_per_second * duration_seconds * 0.95)  # Mostly download
        flow.packets_sent = flow.bytes_sent // 1500
        flow.packets_received = flow.bytes_received // 1500
        
        return flow
    
    def generate_random_flow(self) -> TrafficFlow:
        """
        Generate a random traffic flow.
        
        Returns:
            TrafficFlow object
        """
        slice_type = random.choice([SliceType.PRIORITY, SliceType.NORMAL, SliceType.BACKGROUND])
        
        if slice_type == SliceType.PRIORITY:
            return self.generate_priority_flow()
        elif slice_type == SliceType.NORMAL:
            return self.generate_normal_flow()
        else:
            return self.generate_background_flow()
    
    def generate_traffic_burst(self, num_flows: int, slice_type: Optional[SliceType] = None) -> List[TrafficFlow]:
        """
        Generate a burst of traffic flows.
        
        Args:
            num_flows: Number of flows to generate
            slice_type: Specific slice type (None = random)
            
        Returns:
            List of TrafficFlow objects
        """
        flows = []
        
        for _ in range(num_flows):
            if slice_type == SliceType.PRIORITY:
                flow = self.generate_priority_flow()
            elif slice_type == SliceType.NORMAL:
                flow = self.generate_normal_flow()
            elif slice_type == SliceType.BACKGROUND:
                flow = self.generate_background_flow()
            else:
                flow = self.generate_random_flow()
            
            flows.append(flow)
        
        return flows
    
    def simulate_traffic_pattern(self, duration_minutes: int = 10) -> List[TrafficFlow]:
        """
        Simulate a realistic traffic pattern over time.
        
        Args:
            duration_minutes: Duration of simulation in minutes
            
        Returns:
            List of TrafficFlow objects
        """
        all_flows = []
        total_seconds = duration_minutes * 60
        
        # Simulate periodic traffic
        current_time = 0
        while current_time < total_seconds:
            # Random intervals between traffic bursts
            interval = random.uniform(5, 30)  # 5-30 seconds
            
            # Generate random number of flows
            num_flows = random.randint(1, 5)
            
            # Weight towards normal traffic, occasional priority, rare background
            rand = random.random()
            if rand < 0.1:  # 10% priority
                slice_type = SliceType.PRIORITY
            elif rand < 0.2:  # 10% background
                slice_type = SliceType.BACKGROUND
            else:  # 80% normal
                slice_type = SliceType.NORMAL
            
            flows = self.generate_traffic_burst(num_flows, slice_type)
            all_flows.extend(flows)
            
            current_time += interval
        
        return all_flows

