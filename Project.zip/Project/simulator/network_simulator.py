"""
Network Simulator
Simulates network slicing behavior with bandwidth allocation and prioritization.
"""

import time
import threading
from typing import Dict, List, Optional
from datetime import datetime
from collections import defaultdict
from network_slicing.models import Slice, SliceType, TrafficFlow, NetworkMetrics
from network_slicing.config import NetworkSlicingConfig
from simulator.traffic_generator import TrafficGenerator


class NetworkSimulator:
    """Simulates network slicing behavior."""
    
    def __init__(self, total_bandwidth_mbps: float = 100.0):
        """
        Initialize the network simulator.
        
        Args:
            total_bandwidth_mbps: Total available bandwidth in Mbps
        """
        self.total_bandwidth = total_bandwidth_mbps
        self.config = NetworkSlicingConfig()
        self.traffic_generator = TrafficGenerator()
        
        # Initialize slices
        self.slices: Dict[SliceType, Slice] = {}
        for slice_key, slice_config in self.config.get_all_slices().items():
            slice_type = SliceType(slice_key)
            self.slices[slice_type] = Slice(
                name=slice_config.name,
                slice_type=slice_type,
                priority=slice_config.priority,
                bandwidth_percent=slice_config.bandwidth_percent,
                current_bandwidth_usage=0.0
            )
        
        # Active flows in simulation
        self.active_flows: Dict[str, TrafficFlow] = {}
        
        # Metrics history
        self.metrics_history: List[NetworkMetrics] = []
        
        # Simulation state
        self.is_running = False
        self.simulation_thread: Optional[threading.Thread] = None
    
    def get_slice_bandwidth(self, slice_type: SliceType) -> float:
        """
        Get allocated bandwidth for a slice in Mbps.
        
        Args:
            slice_type: Slice type
            
        Returns:
            Bandwidth in Mbps
        """
        if slice_type in self.slices:
            return self.total_bandwidth * self.slices[slice_type].bandwidth_percent / 100
        return 0.0
    
    def add_traffic_flow(self, flow: TrafficFlow):
        """
        Add a traffic flow to the simulation.
        
        Args:
            flow: TrafficFlow object
        """
        self.active_flows[flow.flow_id] = flow
        
        # Update slice statistics
        if flow.slice_type in self.slices:
            self.slices[flow.slice_type].active_flows += 1
            self.slices[flow.slice_type].total_bytes_sent += flow.bytes_sent
            self.slices[flow.slice_type].total_bytes_received += flow.bytes_received
    
    def remove_traffic_flow(self, flow_id: str):
        """
        Remove a traffic flow from the simulation.
        
        Args:
            flow_id: Flow ID to remove
        """
        if flow_id in self.active_flows:
            flow = self.active_flows[flow_id]
            if flow.slice_type in self.slices:
                self.slices[flow.slice_type].active_flows -= 1
            del self.active_flows[flow_id]
    
    def calculate_slice_bandwidth_usage(self) -> Dict[SliceType, float]:
        """
        Calculate current bandwidth usage per slice.
        
        Returns:
            Dictionary mapping SliceType to bandwidth usage in Mbps
        """
        usage = {}
        
        for slice_type, slice_obj in self.slices.items():
            # Calculate based on active flows
            total_bytes_per_second = 0.0
            
            for flow in self.active_flows.values():
                if flow.slice_type == slice_type and flow.is_active:
                    # Estimate bytes per second (simplified)
                    flow_duration = (datetime.now() - flow.start_time).total_seconds()
                    if flow_duration > 0:
                        total_bytes = flow.get_total_bytes()
                        bytes_per_second = total_bytes / flow_duration
                        total_bytes_per_second += bytes_per_second
            
            # Convert to Mbps
            usage[slice_type] = (total_bytes_per_second * 8) / 1_000_000
            slice_obj.current_bandwidth_usage = usage[slice_type]
        
        return usage
    
    def apply_bandwidth_limits(self):
        """Apply bandwidth limits to slices based on allocation."""
        usage = self.calculate_slice_bandwidth_usage()
        
        for slice_type, current_usage in usage.items():
            allocated = self.get_slice_bandwidth(slice_type)
            
            if current_usage > allocated:
                # Throttle flows in this slice
                excess = current_usage - allocated
                throttle_factor = allocated / current_usage if current_usage > 0 else 1.0
                
                # In a real implementation, this would throttle actual traffic
                # For simulation, we just track the throttling
                self.slices[slice_type].current_bandwidth_usage = allocated
    
    def simulate_latency(self, slice_type: SliceType, base_latency_ms: float = 20.0) -> float:
        """
        Simulate latency for a slice based on priority.
        
        Args:
            slice_type: Slice type
            base_latency_ms: Base network latency
            
        Returns:
            Simulated latency in milliseconds
        """
        if slice_type not in self.slices:
            return base_latency_ms
        
        slice_obj = self.slices[slice_type]
        allocated = self.get_slice_bandwidth(slice_type)
        current_usage = slice_obj.current_bandwidth_usage
        
        # Higher usage = higher latency
        if allocated > 0:
            utilization = min(current_usage / allocated, 1.0)
        else:
            utilization = 1.0
        
        # Priority slices have lower latency
        priority_factor = 1.0 / slice_obj.priority
        
        # Calculate latency: base + (utilization * penalty) * priority_factor
        latency = base_latency_ms + (utilization * 50.0 * priority_factor)
        
        return latency
    
    def simulate_jitter(self, slice_type: SliceType, base_jitter_ms: float = 5.0) -> float:
        """
        Simulate jitter for a slice.
        
        Args:
            slice_type: Slice type
            base_jitter_ms: Base jitter value
            
        Returns:
            Simulated jitter in milliseconds
        """
        if slice_type not in self.slices:
            return base_jitter_ms
        
        slice_obj = self.slices[slice_type]
        allocated = self.get_slice_bandwidth(slice_type)
        current_usage = slice_obj.current_bandwidth_usage
        
        # Higher usage = higher jitter
        if allocated > 0:
            utilization = min(current_usage / allocated, 1.0)
        else:
            utilization = 1.0
        
        # Priority slices have lower jitter
        priority_factor = 1.0 / slice_obj.priority
        
        jitter = base_jitter_ms + (utilization * 20.0 * priority_factor)
        
        return jitter
    
    def collect_metrics(self) -> NetworkMetrics:
        """
        Collect current network metrics.
        
        Returns:
            NetworkMetrics object
        """
        metrics = NetworkMetrics()
        
        # Calculate overall metrics (weighted average)
        total_latency = 0.0
        total_jitter = 0.0
        total_throughput = 0.0
        total_weight = 0.0
        
        for slice_type, slice_obj in self.slices.items():
            latency = self.simulate_latency(slice_type)
            jitter = self.simulate_jitter(slice_type)
            throughput = slice_obj.current_bandwidth_usage
            
            weight = slice_obj.active_flows if slice_obj.active_flows > 0 else 1.0
            
            total_latency += latency * weight
            total_jitter += jitter * weight
            total_throughput += throughput
            total_weight += weight
            
            # Store per-slice metrics
            metrics.add_slice_metric(slice_obj.name, "latency_ms", latency)
            metrics.add_slice_metric(slice_obj.name, "jitter_ms", jitter)
            metrics.add_slice_metric(slice_obj.name, "throughput_mbps", throughput)
            metrics.add_slice_metric(slice_obj.name, "active_flows", float(slice_obj.active_flows))
        
        if total_weight > 0:
            metrics.latency_ms = total_latency / total_weight
            metrics.jitter_ms = total_jitter / total_weight
        
        metrics.throughput_mbps = total_throughput
        
        return metrics
    
    def run_simulation_step(self):
        """Run a single simulation step."""
        # Apply bandwidth limits
        self.apply_bandwidth_limits()
        
        # Collect metrics
        metrics = self.collect_metrics()
        self.metrics_history.append(metrics)
        
        # Keep only last 1000 metrics
        if len(self.metrics_history) > 1000:
            self.metrics_history = self.metrics_history[-1000:]
    
    def start_simulation(self, interval_seconds: float = 1.0):
        """
        Start the simulation loop.
        
        Args:
            interval_seconds: Time between simulation steps
        """
        if self.is_running:
            return
        
        self.is_running = True
        
        def simulation_loop():
            while self.is_running:
                self.run_simulation_step()
                time.sleep(interval_seconds)
        
        self.simulation_thread = threading.Thread(target=simulation_loop, daemon=True)
        self.simulation_thread.start()
    
    def stop_simulation(self):
        """Stop the simulation."""
        self.is_running = False
        if self.simulation_thread:
            self.simulation_thread.join(timeout=2.0)
    
    def generate_test_traffic(self, num_flows: int = 10):
        """
        Generate test traffic flows.
        
        Args:
            num_flows: Number of flows to generate
        """
        flows = self.traffic_generator.generate_traffic_burst(num_flows)
        for flow in flows:
            self.add_traffic_flow(flow)
    
    def get_slice_statistics(self) -> Dict[SliceType, Slice]:
        """Get current statistics for all slices."""
        return self.slices.copy()
    
    def get_metrics_history(self, limit: Optional[int] = None) -> List[NetworkMetrics]:
        """
        Get metrics history.
        
        Args:
            limit: Maximum number of metrics to return (None = all)
            
        Returns:
            List of NetworkMetrics objects
        """
        if limit:
            return self.metrics_history[-limit:]
        return self.metrics_history.copy()

