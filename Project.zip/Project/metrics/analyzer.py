"""
Metrics Analyzer
Analyzes collected network metrics and calculates statistics.
"""

from typing import List, Dict, Optional
from statistics import mean, median, stdev, StatisticsError
from network_slicing.models import NetworkMetrics


class MetricsAnalyzer:
    """Analyzes network performance metrics."""
    
    def __init__(self):
        """Initialize the metrics analyzer."""
        pass
    
    def calculate_average(self, metrics_list: List[NetworkMetrics], metric_name: str) -> float:
        """
        Calculate average value for a metric.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            metric_name: Name of the metric ('latency_ms', 'jitter_ms', 'throughput_mbps')
            
        Returns:
            Average value
        """
        if not metrics_list:
            return 0.0
        
        values = []
        for metrics in metrics_list:
            if metric_name == 'latency_ms':
                values.append(metrics.latency_ms)
            elif metric_name == 'jitter_ms':
                values.append(metrics.jitter_ms)
            elif metric_name == 'throughput_mbps':
                values.append(metrics.throughput_mbps)
            elif metric_name == 'packet_loss_percent':
                values.append(metrics.packet_loss_percent)
        
        if values:
            return mean(values)
        return 0.0
    
    def calculate_median(self, metrics_list: List[NetworkMetrics], metric_name: str) -> float:
        """
        Calculate median value for a metric.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            metric_name: Name of the metric
            
        Returns:
            Median value
        """
        if not metrics_list:
            return 0.0
        
        values = []
        for metrics in metrics_list:
            if metric_name == 'latency_ms':
                values.append(metrics.latency_ms)
            elif metric_name == 'jitter_ms':
                values.append(metrics.jitter_ms)
            elif metric_name == 'throughput_mbps':
                values.append(metrics.throughput_mbps)
        
        if values:
            return median(values)
        return 0.0
    
    def calculate_standard_deviation(self, metrics_list: List[NetworkMetrics], metric_name: str) -> float:
        """
        Calculate standard deviation for a metric.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            metric_name: Name of the metric
            
        Returns:
            Standard deviation
        """
        if not metrics_list or len(metrics_list) < 2:
            return 0.0
        
        values = []
        for metrics in metrics_list:
            if metric_name == 'latency_ms':
                values.append(metrics.latency_ms)
            elif metric_name == 'jitter_ms':
                values.append(metrics.jitter_ms)
            elif metric_name == 'throughput_mbps':
                values.append(metrics.throughput_mbps)
        
        if len(values) >= 2:
            try:
                return stdev(values)
            except StatisticsError:
                return 0.0
        return 0.0
    
    def find_peak(self, metrics_list: List[NetworkMetrics], metric_name: str) -> float:
        """
        Find peak (maximum) value for a metric.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            metric_name: Name of the metric
            
        Returns:
            Peak value
        """
        if not metrics_list:
            return 0.0
        
        values = []
        for metrics in metrics_list:
            if metric_name == 'latency_ms':
                values.append(metrics.latency_ms)
            elif metric_name == 'jitter_ms':
                values.append(metrics.jitter_ms)
            elif metric_name == 'throughput_mbps':
                values.append(metrics.throughput_mbps)
        
        if values:
            return max(values)
        return 0.0
    
    def find_minimum(self, metrics_list: List[NetworkMetrics], metric_name: str) -> float:
        """
        Find minimum value for a metric.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            metric_name: Name of the metric
            
        Returns:
            Minimum value
        """
        if not metrics_list:
            return 0.0
        
        values = []
        for metrics in metrics_list:
            if metric_name == 'latency_ms':
                values.append(metrics.latency_ms)
            elif metric_name == 'jitter_ms':
                values.append(metrics.jitter_ms)
            elif metric_name == 'throughput_mbps':
                values.append(metrics.throughput_mbps)
        
        if values:
            return min(values)
        return 0.0
    
    def analyze_trend(self, metrics_list: List[NetworkMetrics], metric_name: str) -> str:
        """
        Analyze trend for a metric (increasing, decreasing, stable).
        
        Args:
            metrics_list: List of NetworkMetrics objects
            metric_name: Name of the metric
            
        Returns:
            Trend description ('increasing', 'decreasing', 'stable')
        """
        if len(metrics_list) < 2:
            return 'stable'
        
        values = []
        for metrics in metrics_list:
            if metric_name == 'latency_ms':
                values.append(metrics.latency_ms)
            elif metric_name == 'jitter_ms':
                values.append(metrics.jitter_ms)
            elif metric_name == 'throughput_mbps':
                values.append(metrics.throughput_mbps)
        
        if len(values) < 2:
            return 'stable'
        
        # Compare first half average with second half average
        mid = len(values) // 2
        first_half_avg = mean(values[:mid])
        second_half_avg = mean(values[mid:])
        
        threshold = first_half_avg * 0.1  # 10% threshold
        
        if second_half_avg > first_half_avg + threshold:
            return 'increasing'
        elif second_half_avg < first_half_avg - threshold:
            return 'decreasing'
        else:
            return 'stable'
    
    def generate_summary(self, metrics_list: List[NetworkMetrics]) -> Dict[str, Dict[str, float]]:
        """
        Generate a summary statistics for all metrics.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            
        Returns:
            Dictionary with summary statistics
        """
        summary = {
            'latency_ms': {
                'average': self.calculate_average(metrics_list, 'latency_ms'),
                'median': self.calculate_median(metrics_list, 'latency_ms'),
                'min': self.find_minimum(metrics_list, 'latency_ms'),
                'max': self.find_peak(metrics_list, 'latency_ms'),
                'std_dev': self.calculate_standard_deviation(metrics_list, 'latency_ms')
            },
            'jitter_ms': {
                'average': self.calculate_average(metrics_list, 'jitter_ms'),
                'median': self.calculate_median(metrics_list, 'jitter_ms'),
                'min': self.find_minimum(metrics_list, 'jitter_ms'),
                'max': self.find_peak(metrics_list, 'jitter_ms'),
                'std_dev': self.calculate_standard_deviation(metrics_list, 'jitter_ms')
            },
            'throughput_mbps': {
                'average': self.calculate_average(metrics_list, 'throughput_mbps'),
                'median': self.calculate_median(metrics_list, 'throughput_mbps'),
                'min': self.find_minimum(metrics_list, 'throughput_mbps'),
                'max': self.find_peak(metrics_list, 'throughput_mbps'),
                'std_dev': self.calculate_standard_deviation(metrics_list, 'throughput_mbps')
            }
        }
        
        return summary
    
    def analyze_slice_metrics(self, metrics_list: List[NetworkMetrics], slice_name: str) -> Dict[str, float]:
        """
        Analyze metrics for a specific slice.
        
        Args:
            metrics_list: List of NetworkMetrics objects
            slice_name: Name of the slice
            
        Returns:
            Dictionary with slice-specific metrics
        """
        slice_metrics = {
            'latency_ms': [],
            'jitter_ms': [],
            'throughput_mbps': []
        }
        
        for metrics in metrics_list:
            latency = metrics.get_slice_metric(slice_name, 'latency_ms')
            jitter = metrics.get_slice_metric(slice_name, 'jitter_ms')
            throughput = metrics.get_slice_metric(slice_name, 'throughput_mbps')
            
            if latency is not None:
                slice_metrics['latency_ms'].append(latency)
            if jitter is not None:
                slice_metrics['jitter_ms'].append(jitter)
            if throughput is not None:
                slice_metrics['throughput_mbps'].append(throughput)
        
        result = {}
        for metric_name, values in slice_metrics.items():
            if values:
                result[f'{metric_name}_avg'] = mean(values)
                result[f'{metric_name}_min'] = min(values)
                result[f'{metric_name}_max'] = max(values)
        
        return result

