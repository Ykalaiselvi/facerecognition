"""
Application Mapper
Maps applications and network traffic to appropriate network slices.
"""

from typing import Optional, Dict, List
from network_slicing.config import NetworkSlicingConfig
from network_slicing.models import SliceType, TrafficFlow


class ApplicationMapper:
    """Maps applications and traffic to network slices."""
    
    def __init__(self):
        """Initialize the application mapper."""
        self.config = NetworkSlicingConfig()
        self.custom_mappings: Dict[str, str] = {}
    
    def add_custom_mapping(self, application: str, slice_name: str):
        """
        Add a custom application to slice mapping.
        
        Args:
            application: Application name or identifier
            slice_name: Target slice name (priority, normal, background)
        """
        self.custom_mappings[application.lower()] = slice_name.lower()
    
    def get_slice_for_application(self, application_name: str) -> SliceType:
        """
        Get the appropriate slice for an application.
        
        Args:
            application_name: Name of the application
            
        Returns:
            SliceType enum value
        """
        app_lower = application_name.lower()
        
        # Check custom mappings first
        if app_lower in self.custom_mappings:
            slice_name = self.custom_mappings[app_lower]
        else:
            slice_name = self.config.get_application_slice(application_name)
        
        # Convert to SliceType enum
        try:
            return SliceType(slice_name)
        except ValueError:
            return SliceType.NORMAL
    
    def get_slice_for_port(self, port: int) -> SliceType:
        """
        Get the appropriate slice for a network port.
        
        Args:
            port: Network port number
            
        Returns:
            SliceType enum value
        """
        slice_name = self.config.get_port_slice(port)
        try:
            return SliceType(slice_name)
        except ValueError:
            return SliceType.NORMAL
    
    def classify_traffic_flow(self, flow: TrafficFlow) -> SliceType:
        """
        Classify a traffic flow into the appropriate slice.
        
        Args:
            flow: TrafficFlow object to classify
            
        Returns:
            SliceType enum value
        """
        # Priority 1: Application name
        if flow.application_name:
            app_slice = self.get_slice_for_application(flow.application_name)
            if app_slice != SliceType.NORMAL:  # If we have a specific mapping
                return app_slice
        
        # Priority 2: Destination port (more reliable than source port)
        port_slice = self.get_slice_for_port(flow.dest_port)
        if port_slice != SliceType.NORMAL:
            return port_slice
        
        # Priority 3: Source port
        port_slice = self.get_slice_for_port(flow.source_port)
        if port_slice != SliceType.NORMAL:
            return port_slice
        
        # Default: Normal slice
        return SliceType.NORMAL
    
    def get_all_mappings(self) -> Dict[str, List[str]]:
        """
        Get all application mappings organized by slice.
        
        Returns:
            Dictionary mapping slice names to lists of applications
        """
        mappings = {
            'priority': [],
            'normal': [],
            'background': []
        }
        
        # Add standard mappings
        for app, slice_name in self.config.APPLICATION_MAPPING.items():
            mappings[slice_name].append(app)
        
        # Add custom mappings
        for app, slice_name in self.custom_mappings.items():
            if slice_name in mappings:
                mappings[slice_name].append(app)
        
        return mappings
    
    def get_port_mappings(self) -> Dict[str, List[int]]:
        """
        Get all port mappings organized by slice.
        
        Returns:
            Dictionary mapping slice names to lists of ports
        """
        return {
            'priority': sorted(list(self.config.PORT_MAPPING['priority_ports'])),
            'normal': sorted(list(self.config.PORT_MAPPING['normal_ports'])),
            'background': sorted(list(self.config.PORT_MAPPING['background_ports']))
        }

