"""
Flask Web Application for Network Slicing Visualization
Provides a web-based dashboard for monitoring and visualizing network slicing metrics.
"""

from flask import Flask, render_template, jsonify, request
import threading
import time
from datetime import datetime
from typing import Dict, List
import json

from monitor.traffic_monitor import TrafficMonitor
from simulator.network_simulator import NetworkSimulator
from metrics.collector import MetricsCollector
from metrics.analyzer import MetricsAnalyzer
from network_slicing.config import NetworkSlicingConfig
from network_slicing.models import NetworkMetrics, SliceType

app = Flask(__name__)
app.config['SECRET_KEY'] = 'network-slicing-secret-key'

# Global state
monitoring_active = False
simulation_active = False
monitor_thread = None
simulator_thread = None

# Data storage
metrics_history: List[NetworkMetrics] = []
slice_statistics: Dict[str, Dict] = {}
current_metrics: NetworkMetrics = None

# Components
traffic_monitor: TrafficMonitor = None
network_simulator: NetworkSimulator = None
metrics_collector: MetricsCollector = None
metrics_analyzer: MetricsAnalyzer = None


def initialize_components():
    """Initialize monitoring and simulation components."""
    global traffic_monitor, network_simulator, metrics_collector, metrics_analyzer
    
    if traffic_monitor is None:
        traffic_monitor = TrafficMonitor()
    
    if network_simulator is None:
        network_simulator = NetworkSimulator(total_bandwidth_mbps=100.0)
    
    if metrics_collector is None:
        metrics_collector = MetricsCollector()
    
    if metrics_analyzer is None:
        metrics_analyzer = MetricsAnalyzer()


def monitoring_loop():
    """Background thread for continuous monitoring."""
    global monitoring_active, metrics_history, current_metrics, traffic_monitor, metrics_collector
    
    initialize_components()
    
    while monitoring_active:
        try:
            # Collect metrics
            metrics = metrics_collector.collect_metrics()
            current_metrics = metrics
            metrics_history.append(metrics)
            
            # Update slice statistics
            traffic_monitor.update_slice_statistics()
            slice_stats = traffic_monitor.get_slice_statistics()
            
            # Convert to dictionary
            global slice_statistics
            slice_statistics = {}
            for slice_type, slice_obj in slice_stats.items():
                slice_statistics[slice_obj.name] = {
                    'active_flows': slice_obj.active_flows,
                    'bandwidth_percent': slice_obj.bandwidth_percent,
                    'current_bandwidth_usage': slice_obj.current_bandwidth_usage,
                    'total_bytes': slice_obj.get_total_bytes(),
                    'priority': slice_obj.priority
                }
            
            # Keep only recent history
            if len(metrics_history) > 1000:
                metrics_history = metrics_history[-1000:]
            
            time.sleep(2.0)  # Update every 2 seconds
            
        except Exception as e:
            print(f"Monitoring error: {e}")
            time.sleep(5.0)


def simulation_loop():
    """Background thread for network simulation."""
    global simulation_active, metrics_history, current_metrics, network_simulator
    
    initialize_components()
    
    # Generate initial traffic
    network_simulator.generate_test_traffic(num_flows=10)
    network_simulator.start_simulation(interval_seconds=1.0)
    
    while simulation_active:
        try:
            # Collect metrics from simulator
            metrics = network_simulator.collect_metrics()
            current_metrics = metrics
            metrics_history.append(metrics)
            
            # Get slice statistics
            slice_stats = network_simulator.get_slice_statistics()
            
            # Convert to dictionary
            global slice_statistics
            slice_statistics = {}
            for slice_type, slice_obj in slice_stats.items():
                slice_statistics[slice_obj.name] = {
                    'active_flows': slice_obj.active_flows,
                    'bandwidth_percent': slice_obj.bandwidth_percent,
                    'current_bandwidth_usage': slice_obj.current_bandwidth_usage,
                    'total_bytes': slice_obj.get_total_bytes(),
                    'priority': slice_obj.priority
                }
            
            # Keep only recent history
            if len(metrics_history) > 1000:
                metrics_history = metrics_history[-1000:]
            
            time.sleep(2.0)  # Update every 2 seconds
            
        except Exception as e:
            print(f"Simulation error: {e}")
            time.sleep(5.0)
    
    # Stop simulator when done
    if network_simulator:
        network_simulator.stop_simulation()


@app.route('/')
def index():
    """Main dashboard page."""
    return render_template('index.html')


@app.route('/api/metrics/current')
def get_current_metrics():
    """Get current network metrics."""
    global current_metrics
    
    if current_metrics is None:
        return jsonify({
            'latency_ms': 0.0,
            'jitter_ms': 0.0,
            'throughput_mbps': 0.0,
            'packet_loss_percent': 0.0,
            'timestamp': datetime.now().isoformat()
        })
    
    return jsonify({
        'latency_ms': current_metrics.latency_ms,
        'jitter_ms': current_metrics.jitter_ms,
        'throughput_mbps': current_metrics.throughput_mbps,
        'packet_loss_percent': current_metrics.packet_loss_percent,
        'timestamp': current_metrics.timestamp.isoformat(),
        'slice_metrics': current_metrics.slice_metrics
    })


@app.route('/api/metrics/history')
def get_metrics_history():
    """Get metrics history."""
    global metrics_history
    
    limit = request.args.get('limit', type=int, default=100)
    
    # Get recent metrics
    recent_metrics = metrics_history[-limit:] if len(metrics_history) > limit else metrics_history
    
    data = {
        'timestamps': [m.timestamp.isoformat() for m in recent_metrics],
        'latency': [m.latency_ms for m in recent_metrics],
        'jitter': [m.jitter_ms for m in recent_metrics],
        'throughput': [m.throughput_mbps for m in recent_metrics]
    }
    
    return jsonify(data)


@app.route('/api/slices/statistics')
def get_slice_statistics():
    """Get current slice statistics."""
    global slice_statistics
    
    return jsonify(slice_statistics)


@app.route('/api/slices/config')
def get_slice_config():
    """Get slice configuration."""
    config = NetworkSlicingConfig()
    slices = config.get_all_slices()
    
    slice_config = {}
    for slice_key, slice_obj in slices.items():
        slice_config[slice_key] = {
            'name': slice_obj.name,
            'priority': slice_obj.priority,
            'bandwidth_percent': slice_obj.bandwidth_percent,
            'latency_target_ms': slice_obj.latency_target_ms,
            'description': slice_obj.description
        }
    
    return jsonify(slice_config)


@app.route('/api/monitoring/start', methods=['POST'])
def start_monitoring():
    """Start real-time monitoring."""
    global monitoring_active, monitor_thread, simulation_active
    
    if simulation_active:
        return jsonify({'error': 'Simulation is active. Stop simulation first.'}), 400
    
    if not monitoring_active:
        monitoring_active = True
        monitor_thread = threading.Thread(target=monitoring_loop, daemon=True)
        monitor_thread.start()
        return jsonify({'status': 'started', 'message': 'Monitoring started'})
    
    return jsonify({'status': 'already_running', 'message': 'Monitoring already running'})


@app.route('/api/monitoring/stop', methods=['POST'])
def stop_monitoring():
    """Stop real-time monitoring."""
    global monitoring_active
    
    monitoring_active = False
    return jsonify({'status': 'stopped', 'message': 'Monitoring stopped'})


@app.route('/api/simulation/start', methods=['POST'])
def start_simulation():
    """Start network simulation."""
    global simulation_active, simulator_thread, monitoring_active
    
    if monitoring_active:
        return jsonify({'error': 'Monitoring is active. Stop monitoring first.'}), 400
    
    data = request.get_json() or {}
    bandwidth = data.get('bandwidth', 100.0)
    num_flows = data.get('flows', 10)
    
    global network_simulator
    network_simulator = NetworkSimulator(total_bandwidth_mbps=bandwidth)
    network_simulator.generate_test_traffic(num_flows=num_flows)
    
    if not simulation_active:
        simulation_active = True
        simulator_thread = threading.Thread(target=simulation_loop, daemon=True)
        simulator_thread.start()
        return jsonify({'status': 'started', 'message': f'Simulation started with {num_flows} flows'})
    
    return jsonify({'status': 'already_running', 'message': 'Simulation already running'})


@app.route('/api/simulation/stop', methods=['POST'])
def stop_simulation():
    """Stop network simulation."""
    global simulation_active
    
    simulation_active = False
    if network_simulator:
        network_simulator.stop_simulation()
    
    return jsonify({'status': 'stopped', 'message': 'Simulation stopped'})


@app.route('/api/status')
def get_status():
    """Get current application status."""
    global monitoring_active, simulation_active, metrics_history
    
    return jsonify({
        'monitoring_active': monitoring_active,
        'simulation_active': simulation_active,
        'metrics_count': len(metrics_history),
        'has_data': current_metrics is not None
    })


@app.route('/api/analyzer/summary')
def get_analysis_summary():
    """Get metrics analysis summary."""
    global metrics_history, metrics_analyzer
    
    if not metrics_history or metrics_analyzer is None:
        return jsonify({'error': 'No metrics data available'}), 404
    
    summary = metrics_analyzer.generate_summary(metrics_history)
    return jsonify(summary)


if __name__ == '__main__':
    initialize_components()
    app.run(debug=True, host='0.0.0.0', port=5000)

