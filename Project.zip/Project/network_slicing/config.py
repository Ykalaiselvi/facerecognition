"""
Network Slicing Configuration
Defines slice configurations, bandwidth allocations, and application mappings.
"""

from dataclasses import dataclass
from typing import Dict, List, Set


@dataclass
class SliceConfig:
    """Configuration for a single network slice."""
    name: str
    priority: int  # Higher number = higher priority
    bandwidth_percent: float  # Percentage of total bandwidth
    latency_target_ms: float  # Target latency in milliseconds
    description: str


class NetworkSlicingConfig:
    """Main configuration class for network slicing."""
    
    # Slice definitions
    SLICES = {
        'priority': SliceConfig(
            name='Priority',
            priority=3,
            bandwidth_percent=50.0,
            latency_target_ms=50.0,
            description='Online classes, video calls, real-time communication'
        ),
        'normal': SliceConfig(
            name='Normal',
            priority=2,
            bandwidth_percent=35.0,
            latency_target_ms=100.0,
            description='General web browsing, moderate data usage'
        ),
        'background': SliceConfig(
            name='Background',
            priority=1,
            bandwidth_percent=15.0,
            latency_target_ms=200.0,
            description='Software updates, bulk downloads, non-urgent activities'
        )
    }
    
    # Application to slice mapping
    APPLICATION_MAPPING = {
        # Priority slice applications
        'zoom': 'priority',
        'zoom.exe': 'priority',
        'teams': 'priority',
        'msteams.exe': 'priority',
        'skype': 'priority',
        'skype.exe': 'priority',
        'webex': 'priority',
        'webexmta.exe': 'priority',
        'gotomeeting': 'priority',
        'google meet': 'priority',
        'meet.google.com': 'priority',
        
        # Normal slice applications
        'chrome': 'normal',
        'chrome.exe': 'normal',
        'firefox': 'normal',
        'firefox.exe': 'normal',
        'edge': 'normal',
        'msedge.exe': 'normal',
        'youtube': 'normal',
        'netflix': 'normal',
        'spotify': 'normal',
        
        # Background slice applications
        'windows update': 'background',
        'wuauclt.exe': 'background',
        'svchost.exe': 'background',  # Often used for updates
        'steam': 'background',
        'steam.exe': 'background',
        'torrent': 'background',
        'utorrent': 'background',
    }
    
    # Port-based classification
    PORT_MAPPING = {
        # Priority ports (video conferencing)
        'priority_ports': {
            443,  # HTTPS (Zoom, Teams use this)
            8801, 8802, 8803, 8804, 8805, 8806, 8807, 8808, 8809, 8810,  # Zoom media ports
            3478, 3479,  # STUN/TURN for WebRTC
            5004, 5005,  # RTP
            5060, 5061,  # SIP
            8080,  # Alternative HTTP
        },
        # Normal ports (web browsing, streaming)
        'normal_ports': {
            80,   # HTTP
            443,  # HTTPS (also used by streaming)
            1935,  # RTMP
            554,   # RTSP
        },
        # Background ports (file transfer, updates)
        'background_ports': {
            21,   # FTP
            22,   # SSH
            25,   # SMTP
            53,   # DNS
            123,  # NTP
            445,  # SMB
            873,  # RSYNC
        }
    }
    
    # IP-based classification (optional, for specific services)
    IP_MAPPING = {
        'priority_ips': set(),  # Can be populated with known video conferencing IPs
        'normal_ips': set(),
        'background_ips': set(),
    }
    
    @classmethod
    def get_slice_by_name(cls, slice_name: str) -> SliceConfig:
        """Get slice configuration by name."""
        return cls.SLICES.get(slice_name.lower())
    
    @classmethod
    def get_all_slices(cls) -> Dict[str, SliceConfig]:
        """Get all slice configurations."""
        return cls.SLICES
    
    @classmethod
    def get_application_slice(cls, app_name: str) -> str:
        """Get slice name for an application."""
        app_lower = app_name.lower()
        for key, slice_name in cls.APPLICATION_MAPPING.items():
            if key in app_lower:
                return slice_name
        return 'normal'  # Default to normal
    
    @classmethod
    def get_port_slice(cls, port: int) -> str:
        """Get slice name for a port."""
        if port in cls.PORT_MAPPING['priority_ports']:
            return 'priority'
        elif port in cls.PORT_MAPPING['background_ports']:
            return 'background'
        else:
            return 'normal'
    
    @classmethod
    def validate_bandwidth_allocation(cls) -> bool:
        """Validate that bandwidth percentages sum to 100."""
        total = sum(slice.bandwidth_percent for slice in cls.SLICES.values())
        return abs(total - 100.0) < 0.01

