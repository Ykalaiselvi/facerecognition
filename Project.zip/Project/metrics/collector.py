"""
Metrics Collector
Collects network performance metrics including latency, jitter, and throughput.
"""

import time
import subprocess
import platform
import socket
from typing import Optional, List, Dict
from datetime import datetime
from network_slicing.models import NetworkMetrics
import psutil


class MetricsCollector:
    """Collects network performance metrics."""
    
    def __init__(self, target_host: str = "8.8.8.8", ping_count: int = 4):
        """
        Initialize the metrics collector.
        
        Args:
            target_host: Host to ping for latency measurement (default: Google DNS)
            ping_count: Number of ping packets to send
        """
        self.target_host = target_host
        self.ping_count = ping_count
        self.ping_history: List[float] = []
        self.max_history = 100
    
    def ping_host(self, host: Optional[str] = None) -> Optional[float]:
        """
        Ping a host and return average latency.
        
        Args:
            host: Host to ping (None = use default)
            
        Returns:
            Average latency in milliseconds, or None if ping fails
        """
        target = host or self.target_host
        
        try:
            if platform.system() == "Windows":
                # Windows ping command
                result = subprocess.run(
                    ["ping", "-n", str(self.ping_count), target],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                if result.returncode == 0:
                    # Parse Windows ping output: "Average = XXms"
                    lines = result.stdout.split('\n')
                    for line in lines:
                        if "Average" in line and "ms" in line:
                            try:
                                # Extract number before "ms"
                                parts = line.split("=")
                                if len(parts) > 1:
                                    latency_str = parts[-1].strip().replace("ms", "").strip()
                                    latency = float(latency_str)
                                    self.ping_history.append(latency)
                                    if len(self.ping_history) > self.max_history:
                                        self.ping_history.pop(0)
                                    return latency
                            except (ValueError, IndexError):
                                pass
            else:
                # Linux/Mac ping command
                result = subprocess.run(
                    ["ping", "-c", str(self.ping_count), target],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                if result.returncode == 0:
                    # Parse Linux ping output: "min/avg/max/mdev = X/X/X/X ms"
                    lines = result.stdout.split('\n')
                    for line in lines:
                        if "min/avg/max" in line or "round-trip" in line:
                            try:
                                # Extract average
                                parts = line.split("=")
                                if len(parts) > 1:
                                    stats = parts[-1].strip().split("/")
                                    if len(stats) >= 2:
                                        latency = float(stats[1])
                                        self.ping_history.append(latency)
                                        if len(self.ping_history) > self.max_history:
                                            self.ping_history.pop(0)
                                        return latency
                            except (ValueError, IndexError):
                                pass
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            pass
        
        return None
    
    def calculate_jitter(self) -> float:
        """
        Calculate jitter from ping history.
        Jitter is the variation in latency.
        
        Returns:
            Jitter in milliseconds
        """
        if len(self.ping_history) < 2:
            return 0.0
        
        # Calculate differences between consecutive pings
        differences = []
        for i in range(1, len(self.ping_history)):
            diff = abs(self.ping_history[i] - self.ping_history[i-1])
            differences.append(diff)
        
        if differences:
            # Jitter is the average of absolute differences
            return sum(differences) / len(differences)
        
        return 0.0
    
    def get_throughput(self, interface_name: Optional[str] = None, duration_seconds: float = 1.0) -> float:
        """
        Measure current network throughput.
        
        Args:
            interface_name: Network interface name (None = aggregate)
            duration_seconds: Duration to measure over
            
        Returns:
            Throughput in Mbps
        """
        # Get initial stats
        if interface_name:
            net_io = psutil.net_io_counters(pernic=True)
            if interface_name in net_io:
                initial = net_io[interface_name]
            else:
                return 0.0
        else:
            initial = psutil.net_io_counters()
        
        initial_bytes = initial.bytes_sent + initial.bytes_recv
        initial_time = time.time()
        
        # Wait and measure
        time.sleep(duration_seconds)
        
        # Get final stats
        if interface_name:
            net_io = psutil.net_io_counters(pernic=True)
            if interface_name in net_io:
                final = net_io[interface_name]
            else:
                return 0.0
        else:
            final = psutil.net_io_counters()
        
        final_bytes = final.bytes_sent + final.bytes_recv
        final_time = time.time()
        
        # Calculate throughput
        elapsed = final_time - initial_time
        if elapsed > 0:
            bytes_delta = final_bytes - initial_bytes
            throughput_mbps = (bytes_delta * 8) / (elapsed * 1_000_000)
            return throughput_mbps
        
        return 0.0
    
    def collect_metrics(self, interface_name: Optional[str] = None) -> NetworkMetrics:
        """
        Collect all network metrics.
        
        Args:
            interface_name: Network interface name (None = aggregate)
            
        Returns:
            NetworkMetrics object
        """
        metrics = NetworkMetrics()
        
        # Collect latency
        latency = self.ping_host()
        if latency:
            metrics.latency_ms = latency
        
        # Calculate jitter
        metrics.jitter_ms = self.calculate_jitter()
        
        # Collect throughput
        metrics.throughput_mbps = self.get_throughput(interface_name)
        
        return metrics
    
    def get_gateway_ip(self) -> Optional[str]:
        """
        Get the default gateway IP address.
        
        Returns:
            Gateway IP address or None
        """
        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["route", "print", "0.0.0.0"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    lines = result.stdout.split('\n')
                    for line in lines:
                        if "0.0.0.0" in line and "On-link" not in line:
                            parts = line.split()
                            if len(parts) >= 3:
                                return parts[2]
            else:
                # Linux/Mac
                result = subprocess.run(
                    ["ip", "route", "show", "default"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    parts = result.stdout.split()
                    if "via" in parts:
                        idx = parts.index("via")
                        if idx + 1 < len(parts):
                            return parts[idx + 1]
        except Exception:
            pass
        
        return None

