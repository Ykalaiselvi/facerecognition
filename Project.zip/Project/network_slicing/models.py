"""
Data Models for Network Slicing
Defines data structures for slices, traffic flows, and metrics.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, List
from enum import Enum


class SliceType(Enum):
    """Network slice types."""
    PRIORITY = "priority"
    NORMAL = "normal"
    BACKGROUND = "background"


@dataclass
class Slice:
    """Represents a network slice."""
    name: str
    slice_type: SliceType
    priority: int
    bandwidth_percent: float
    current_bandwidth_usage: float = 0.0  # Current usage in Mbps
    active_flows: int = 0
    total_bytes_sent: int = 0
    total_bytes_received: int = 0
    
    def get_total_bytes(self) -> int:
        """Get total bytes (sent + received)."""
        return self.total_bytes_sent + self.total_bytes_received
    
    def reset_counters(self):
        """Reset byte counters."""
        self.total_bytes_sent = 0
        self.total_bytes_received = 0
        self.active_flows = 0


@dataclass
class TrafficFlow:
    """Represents a network traffic flow."""
    flow_id: str
    slice_type: SliceType
    source_ip: str
    dest_ip: str
    source_port: int
    dest_port: int
    protocol: str
    application_name: Optional[str] = None
    bytes_sent: int = 0
    bytes_received: int = 0
    packets_sent: int = 0
    packets_received: int = 0
    start_time: datetime = field(default_factory=datetime.now)
    last_update: datetime = field(default_factory=datetime.now)
    is_active: bool = True
    
    def get_total_bytes(self) -> int:
        """Get total bytes for this flow."""
        return self.bytes_sent + self.bytes_received
    
    def update(self, bytes_sent: int = 0, bytes_received: int = 0, 
               packets_sent: int = 0, packets_received: int = 0):
        """Update flow statistics."""
        self.bytes_sent += bytes_sent
        self.bytes_received += bytes_received
        self.packets_sent += packets_sent
        self.packets_received += packets_received
        self.last_update = datetime.now()


@dataclass
class NetworkMetrics:
    """Network performance metrics."""
    timestamp: datetime = field(default_factory=datetime.now)
    latency_ms: float = 0.0
    jitter_ms: float = 0.0
    throughput_mbps: float = 0.0
    packet_loss_percent: float = 0.0
    
    # Per-slice metrics
    slice_metrics: Dict[str, Dict[str, float]] = field(default_factory=dict)
    
    def add_slice_metric(self, slice_name: str, metric_name: str, value: float):
        """Add a metric for a specific slice."""
        if slice_name not in self.slice_metrics:
            self.slice_metrics[slice_name] = {}
        self.slice_metrics[slice_name][metric_name] = value
    
    def get_slice_metric(self, slice_name: str, metric_name: str) -> Optional[float]:
        """Get a metric for a specific slice."""
        return self.slice_metrics.get(slice_name, {}).get(metric_name)


@dataclass
class TrafficClassificationRule:
    """Rule for classifying traffic into slices."""
    rule_id: str
    rule_type: str  # 'port', 'application', 'ip', 'protocol'
    match_value: str
    target_slice: SliceType
    priority: int = 0  # Higher priority rules are checked first
    enabled: bool = True
    
    def matches(self, flow: TrafficFlow) -> bool:
        """Check if this rule matches a traffic flow."""
        if not self.enabled:
            return False
            
        if self.rule_type == 'port':
            return (str(self.match_value) == str(flow.dest_port) or 
                    str(self.match_value) == str(flow.source_port))
        elif self.rule_type == 'application':
            return self.match_value.lower() in (flow.application_name or '').lower()
        elif self.rule_type == 'ip':
            return (self.match_value == flow.source_ip or 
                    self.match_value == flow.dest_ip)
        elif self.rule_type == 'protocol':
            return self.match_value.lower() == flow.protocol.lower()
        
        return False

