"""
Dashboard
Real-time dashboard for displaying network metrics.
"""

import time
from typing import List, Optional
from datetime import datetime
from network_slicing.models import NetworkMetrics
from visualization.charts import ChartGenerator


class Dashboard:
    """Real-time dashboard for network metrics visualization."""
    
    def __init__(self, update_interval: float = 1.0):
        """
        Initialize the dashboard.
        
        Args:
            update_interval: Update interval in seconds
        """
        self.update_interval = update_interval
        self.chart_generator = ChartGenerator()
        self.metrics_history: List[NetworkMetrics] = []
        self.max_history = 1000
    
    def add_metrics(self, metrics: NetworkMetrics):
        """
        Add metrics to the dashboard history.
        
        Args:
            metrics: NetworkMetrics object
        """
        self.metrics_history.append(metrics)
        
        # Keep only recent history
        if len(self.metrics_history) > self.max_history:
            self.metrics_history = self.metrics_history[-self.max_history:]
    
    def display_current_metrics(self, metrics: NetworkMetrics):
        """
        Display current metrics in console.
        
        Args:
            metrics: NetworkMetrics object
        """
        print("\n" + "="*60)
        print("NETWORK METRICS DASHBOARD")
        print("="*60)
        print(f"Timestamp: {metrics.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Latency:    {metrics.latency_ms:.2f} ms")
        print(f"Jitter:     {metrics.jitter_ms:.2f} ms")
        print(f"Throughput: {metrics.throughput_mbps:.2f} Mbps")
        print("-"*60)
        
        if metrics.slice_metrics:
            print("Per-Slice Metrics:")
            for slice_name, slice_metrics in metrics.slice_metrics.items():
                print(f"  {slice_name}:")
                for metric_name, value in slice_metrics.items():
                    print(f"    {metric_name}: {value:.2f}")
        print("="*60 + "\n")
    
    def generate_report(self, output_dir: str = "reports"):
        """
        Generate a comprehensive metrics report with charts.
        
        Args:
            output_dir: Directory to save report files
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        if not self.metrics_history:
            print("No metrics data available for report generation.")
            return
        
        print(f"Generating report in {output_dir}/...")
        
        # Generate individual charts
        self.chart_generator.plot_latency(
            self.metrics_history,
            save_path=f"{output_dir}/latency_chart.png"
        )
        
        self.chart_generator.plot_jitter(
            self.metrics_history,
            save_path=f"{output_dir}/jitter_chart.png"
        )
        
        self.chart_generator.plot_throughput(
            self.metrics_history,
            save_path=f"{output_dir}/throughput_chart.png"
        )
        
        # Generate overview chart
        self.chart_generator.plot_all_metrics(
            self.metrics_history,
            save_path=f"{output_dir}/metrics_overview.png"
        )
        
        # Generate slice comparison charts
        self.chart_generator.plot_slice_comparison(
            self.metrics_history,
            metric_name="latency_ms",
            save_path=f"{output_dir}/slice_latency_comparison.png"
        )
        
        self.chart_generator.plot_slice_comparison(
            self.metrics_history,
            metric_name="throughput_mbps",
            save_path=f"{output_dir}/slice_throughput_comparison.png"
        )
        
        print(f"Report generated successfully in {output_dir}/")
    
    def get_recent_metrics(self, count: int = 10) -> List[NetworkMetrics]:
        """
        Get recent metrics.
        
        Args:
            count: Number of recent metrics to return
            
        Returns:
            List of NetworkMetrics objects
        """
        return self.metrics_history[-count:] if self.metrics_history else []
    
    def clear_history(self):
        """Clear metrics history."""
        self.metrics_history = []

