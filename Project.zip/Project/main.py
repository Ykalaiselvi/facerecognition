"""
Network Slicing Main Application
CLI interface for network slicing configuration, monitoring, and simulation.
"""

import argparse
import sys
import time
from pathlib import Path
from config_generator.router_config import RouterConfigGenerator
from config_generator.application_mapper import ApplicationMapper
from monitor.traffic_monitor import TrafficMonitor
from simulator.network_simulator import NetworkSimulator
from metrics.collector import MetricsCollector
from metrics.analyzer import MetricsAnalyzer
from visualization.dashboard import Dashboard


def generate_config(args):
    """Generate router configuration files."""
    print("Generating router configuration files...")
    
    generator = RouterConfigGenerator(total_bandwidth_mbps=args.bandwidth)
    output_dir = args.output or "config_examples"
    
    generator.generate_all_configs(output_dir)
    
    print(f"\nConfiguration files generated in '{output_dir}/':")
    print("- openwrt_qos.sh - OpenWrt SQM configuration")
    print("- ddwrt_qos.sh - DD-WRT QoS configuration")
    print("- generic_qos.json - Generic JSON configuration")
    print("\nPlease review and apply these configurations to your router.")


def monitor_traffic(args):
    """Monitor network traffic and classify into slices."""
    print("Starting traffic monitoring...")
    print("Press Ctrl+C to stop\n")
    
    monitor = TrafficMonitor(interface_name=args.interface)
    
    try:
        while True:
            # Update slice statistics
            monitor.update_slice_statistics()
            slice_stats = monitor.get_slice_statistics()
            
            # Display statistics
            print("\n" + "="*60)
            print("TRAFFIC MONITORING - Network Slices")
            print("="*60)
            
            for slice_type, slice_obj in slice_stats.items():
                print(f"\n{slice_obj.name} Slice (Priority {slice_obj.priority}):")
                print(f"  Active Flows: {slice_obj.active_flows}")
                print(f"  Bandwidth Allocation: {slice_obj.bandwidth_percent}%")
                print(f"  Total Bytes: {slice_obj.get_total_bytes():,}")
            
            time.sleep(args.interval)
            
    except KeyboardInterrupt:
        print("\n\nMonitoring stopped.")


def run_simulation(args):
    """Run network slicing simulation."""
    print("Starting network slicing simulation...")
    print("Press Ctrl+C to stop\n")
    
    simulator = NetworkSimulator(total_bandwidth_mbps=args.bandwidth)
    dashboard = Dashboard()
    
    # Generate initial test traffic
    simulator.generate_test_traffic(num_flows=args.flows)
    
    # Start simulation
    simulator.start_simulation(interval_seconds=args.interval)
    
    try:
        while True:
            # Collect metrics
            metrics = simulator.collect_metrics()
            dashboard.add_metrics(metrics)
            dashboard.display_current_metrics(metrics)
            
            # Display slice statistics
            slice_stats = simulator.get_slice_statistics()
            print("\nSlice Statistics:")
            for slice_type, slice_obj in slice_stats.items():
                print(f"  {slice_obj.name}: {slice_obj.active_flows} flows, "
                      f"{slice_obj.current_bandwidth_usage:.2f} Mbps")
            
            time.sleep(args.interval)
            
    except KeyboardInterrupt:
        print("\n\nStopping simulation...")
        simulator.stop_simulation()
        
        # Generate report if requested
        if args.report:
            print("Generating simulation report...")
            dashboard.generate_report(output_dir=args.report)
        
        print("Simulation stopped.")


def collect_metrics(args):
    """Collect and display network metrics."""
    print("Collecting network metrics...")
    print("Press Ctrl+C to stop\n")
    
    collector = MetricsCollector(target_host=args.target, ping_count=args.ping_count)
    dashboard = Dashboard()
    analyzer = MetricsAnalyzer()
    
    metrics_list = []
    
    try:
        while True:
            # Collect metrics
            metrics = collector.collect_metrics(interface_name=args.interface)
            metrics_list.append(metrics)
            dashboard.add_metrics(metrics)
            dashboard.display_current_metrics(metrics)
            
            # Keep only recent metrics for analysis
            if len(metrics_list) > 100:
                metrics_list = metrics_list[-100:]
            
            time.sleep(args.interval)
            
    except KeyboardInterrupt:
        print("\n\nMetrics collection stopped.")
        
        # Generate summary if we have data
        if metrics_list:
            print("\nGenerating summary statistics...")
            summary = analyzer.generate_summary(metrics_list)
            
            print("\n" + "="*60)
            print("METRICS SUMMARY")
            print("="*60)
            for metric_name, stats in summary.items():
                print(f"\n{metric_name.replace('_', ' ').title()}:")
                print(f"  Average: {stats['average']:.2f}")
                print(f"  Median:  {stats['median']:.2f}")
                print(f"  Min:     {stats['min']:.2f}")
                print(f"  Max:     {stats['max']:.2f}")
                print(f"  Std Dev: {stats['std_dev']:.2f}")
        
        # Generate report if requested
        if args.report:
            print(f"\nGenerating metrics report in '{args.report}/'...")
            dashboard.generate_report(output_dir=args.report)


def show_mappings(args):
    """Show application and port mappings."""
    mapper = ApplicationMapper()
    
    print("="*60)
    print("APPLICATION MAPPINGS")
    print("="*60)
    
    app_mappings = mapper.get_all_mappings()
    for slice_name, applications in app_mappings.items():
        print(f"\n{slice_name.upper()} Slice:")
        for app in applications[:20]:  # Show first 20
            print(f"  - {app}")
        if len(applications) > 20:
            print(f"  ... and {len(applications) - 20} more")
    
    print("\n" + "="*60)
    print("PORT MAPPINGS")
    print("="*60)
    
    port_mappings = mapper.get_port_mappings()
    for slice_name, ports in port_mappings.items():
        print(f"\n{slice_name.upper()} Slice:")
        print(f"  Ports: {', '.join(map(str, ports[:15]))}")
        if len(ports) > 15:
            print(f"  ... and {len(ports) - 15} more ports")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Network Slicing for Online Classes and Video Streaming",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate router configuration files
  python main.py config --bandwidth 100

  # Monitor network traffic
  python main.py monitor --interval 2

  # Run simulation
  python main.py simulate --bandwidth 100 --flows 10 --report reports/

  # Collect metrics
  python main.py metrics --interval 5 --report reports/

  # Show mappings
  python main.py mappings
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Config generation command
    config_parser = subparsers.add_parser('config', help='Generate router configuration files')
    config_parser.add_argument('--bandwidth', type=float, default=100.0,
                              help='Total bandwidth in Mbps (default: 100)')
    config_parser.add_argument('--output', type=str, default='config_examples',
                              help='Output directory (default: config_examples)')
    
    # Traffic monitoring command
    monitor_parser = subparsers.add_parser('monitor', help='Monitor network traffic')
    monitor_parser.add_argument('--interface', type=str, default=None,
                               help='Network interface name (default: all)')
    monitor_parser.add_argument('--interval', type=float, default=2.0,
                               help='Update interval in seconds (default: 2.0)')
    
    # Simulation command
    sim_parser = subparsers.add_parser('simulate', help='Run network slicing simulation')
    sim_parser.add_argument('--bandwidth', type=float, default=100.0,
                           help='Total bandwidth in Mbps (default: 100)')
    sim_parser.add_argument('--flows', type=int, default=10,
                           help='Number of initial traffic flows (default: 10)')
    sim_parser.add_argument('--interval', type=float, default=1.0,
                           help='Update interval in seconds (default: 1.0)')
    sim_parser.add_argument('--report', type=str, default=None,
                           help='Generate report in specified directory')
    
    # Metrics collection command
    metrics_parser = subparsers.add_parser('metrics', help='Collect network metrics')
    metrics_parser.add_argument('--interface', type=str, default=None,
                               help='Network interface name (default: all)')
    metrics_parser.add_argument('--target', type=str, default='8.8.8.8',
                               help='Ping target host (default: 8.8.8.8)')
    metrics_parser.add_argument('--ping-count', type=int, default=4,
                               help='Number of ping packets (default: 4)')
    metrics_parser.add_argument('--interval', type=float, default=5.0,
                               help='Collection interval in seconds (default: 5.0)')
    metrics_parser.add_argument('--report', type=str, default=None,
                               help='Generate report in specified directory')
    
    # Mappings command
    subparsers.add_parser('mappings', help='Show application and port mappings')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    try:
        if args.command == 'config':
            generate_config(args)
        elif args.command == 'monitor':
            monitor_traffic(args)
        elif args.command == 'simulate':
            run_simulation(args)
        elif args.command == 'metrics':
            collect_metrics(args)
        elif args.command == 'mappings':
            show_mappings(args)
    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()

