# Network Slicing for Online Classes and Video Streaming

A Python-based network slicing solution that provides configuration tools for real-world router deployment, traffic monitoring/simulation capabilities, and basic metrics visualization. This system divides network traffic into three priority slices to ensure online classes and video conferencing receive the necessary resources for smooth, uninterrupted performance.

## Features

- **Router Configuration Generation**: Generate QoS configuration files for OpenWrt, DD-WRT, and generic routers
- **Traffic Monitoring**: Monitor network traffic and classify it into priority slices
- **Network Simulation**: Simulate network slicing behavior with configurable parameters
- **Metrics Collection**: Collect latency, jitter, and throughput metrics
- **Visualization**: Basic charts and dashboards for metrics display
- **Windows Compatible**: Designed to work on Windows platform

## Network Slices

The system implements three network slices:

1. **Priority Slice** (50% bandwidth)
   - Online classes, video calls, real-time communication
   - Low latency target: 50ms
   - Applications: Zoom, Teams, Skype, WebEx, Google Meet

2. **Normal Slice** (35% bandwidth)
   - General web browsing, moderate data usage
   - Latency target: 100ms
   - Applications: Chrome, Firefox, YouTube, Netflix

3. **Background Slice** (15% bandwidth)
   - Software updates, bulk downloads, non-urgent activities
   - Latency target: 200ms
   - Applications: Windows Update, Steam, file downloads

## Installation

### Prerequisites

- Python 3.7 or higher
- Windows 10/11 (or Linux/Mac with modifications)
- Web browser (Chrome, Firefox, Edge, etc.) for the Flask dashboard

### Setup

1. Clone or download this repository

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Verify installation:
```bash
python main.py --help
```

## Usage

### Web Dashboard (Flask Application)

Start the web-based dashboard for real-time visualization:

```bash
python app.py
```

Then open your browser and navigate to: `http://localhost:5000`

**Features:**
- Real-time metrics visualization (latency, jitter, throughput)
- Interactive charts using Chart.js
- Network slice statistics and bandwidth usage
- Start/stop monitoring and simulation from the web interface
- Responsive design for desktop and mobile

**Web Dashboard Controls:**
- **Start Monitoring**: Begin real-time network traffic monitoring
- **Stop Monitoring**: Stop the monitoring process
- **Start Simulation**: Run network slicing simulation (prompts for bandwidth and flow count)
- **Stop Simulation**: Stop the simulation

The dashboard automatically updates every 2 seconds with the latest metrics.

### Generate Router Configuration Files

Generate QoS configuration files for your router:

```bash
python main.py config --bandwidth 100 --output config_examples
```

This creates configuration files for:
- OpenWrt (SQM configuration)
- DD-WRT (QoS scripts)
- Generic routers (JSON format)

**Note**: Review and apply these configurations manually to your router. The exact steps depend on your router model and firmware.

### Monitor Network Traffic

Monitor real-time network traffic and see how it's classified into slices:

```bash
python main.py monitor --interval 2
```

Options:
- `--interface`: Specify network interface (default: all interfaces)
- `--interval`: Update interval in seconds (default: 2.0)

### Run Network Simulation

Simulate network slicing behavior with synthetic traffic:

```bash
python main.py simulate --bandwidth 100 --flows 10 --interval 1 --report reports/
```

Options:
- `--bandwidth`: Total bandwidth in Mbps (default: 100)
- `--flows`: Number of initial traffic flows (default: 10)
- `--interval`: Update interval in seconds (default: 1.0)
- `--report`: Generate report in specified directory

### Collect Network Metrics

Collect and analyze network performance metrics:

```bash
python main.py metrics --interval 5 --target 8.8.8.8 --report reports/
```

Options:
- `--interface`: Network interface name (default: all)
- `--target`: Ping target host (default: 8.8.8.8)
- `--ping-count`: Number of ping packets (default: 4)
- `--interval`: Collection interval in seconds (default: 5.0)
- `--report`: Generate report with charts

### Show Application Mappings

View how applications and ports are mapped to slices:

```bash
python main.py mappings
```

## Router Configuration Guide

### OpenWrt Configuration

1. SSH into your OpenWrt router
2. Install required packages:
```bash
opkg update
opkg install sqm-scripts luci-app-sqm
```
3. Review and apply the generated `openwrt_qos.sh` script
4. Configure SQM via LuCI web interface or command line

### DD-WRT Configuration

1. Access your router's web interface
2. Navigate to Administration -> Commands
3. Copy and paste the commands from `ddwrt_qos.sh`
4. Click "Save Startup" and reboot

### Generic Router Configuration

For routers that support JSON-based QoS configuration:
1. Import the `generic_qos.json` file through your router's web interface
2. Adjust bandwidth values according to your connection speed
3. Apply the configuration

**Important**: Always backup your router configuration before making changes!

## Project Structure

```
Project/
├── network_slicing/          # Core configuration and models
│   ├── config.py             # Slice configurations and mappings
│   └── models.py             # Data models
├── config_generator/         # Router configuration tools
│   ├── router_config.py      # Configuration file generator
│   └── application_mapper.py # Application to slice mapping
├── monitor/                  # Traffic monitoring
│   ├── traffic_monitor.py   # Network traffic monitor
│   └── classifier.py         # Traffic classification
├── simulator/                # Network simulation
│   ├── network_simulator.py  # Simulation engine
│   └── traffic_generator.py # Traffic pattern generator
├── metrics/                  # Metrics collection
│   ├── collector.py          # Metrics collector
│   └── analyzer.py           # Metrics analyzer
├── visualization/            # Visualization
│   ├── dashboard.py          # Dashboard
│   └── charts.py             # Chart generator
├── config_examples/          # Generated config files
├── main.py                   # Main CLI application
├── requirements.txt          # Python dependencies
└── README.md                 # This file
```

## How It Works

### Traffic Classification

Traffic is classified into slices based on:

1. **Application Name**: Process names (e.g., zoom.exe → Priority slice)
2. **Port Numbers**: Known ports (e.g., 443, 8801-8810 → Priority slice)
3. **IP Addresses**: Optional IP-based classification

### Bandwidth Allocation

Each slice receives a percentage of total bandwidth:
- Priority: 50% (guaranteed for critical applications)
- Normal: 35% (standard web traffic)
- Background: 15% (non-urgent activities)

### Metrics Collection

The system collects:
- **Latency**: Round-trip time to a target host (ping-based)
- **Jitter**: Variation in latency (packet delay variation)
- **Throughput**: Current bandwidth usage per slice

## Limitations

### Windows Platform

- No direct access to Linux `tc` (traffic control) commands
- Router configuration files must be applied manually
- Some network monitoring features may require administrator privileges

### Router Configuration

- Configuration files are templates and may need customization
- Router firmware versions vary; some commands may need adjustment
- Always test in a controlled environment first

## Troubleshooting

### Permission Errors

Some features require administrator privileges on Windows:
- Right-click Command Prompt/PowerShell → "Run as administrator"
- Or use: `python -m pip install --user -r requirements.txt`

### Ping Failures

If ping fails:
- Check internet connectivity
- Try a different target host: `--target 1.1.1.1`
- Ensure firewall allows ICMP packets

### No Traffic Detected

If monitoring shows no traffic:
- Check network interface name: `python -c "import psutil; print(list(psutil.net_if_addrs().keys()))"`
- Use `--interface` to specify the correct interface
- Ensure applications are generating network traffic

## Contributing

This is an educational/research project. Feel free to:
- Report issues
- Suggest improvements
- Submit pull requests

## License

This project is provided as-is for educational and research purposes.

## References

- Network Slicing: A method to divide physical networks into virtual slices
- Quality of Service (QoS): Traffic prioritization and bandwidth management
- SQM (Smart Queue Management): OpenWrt's QoS implementation

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review router documentation for QoS setup
3. Consult network administrator for production deployments

---

**Note**: This tool generates configuration files and provides monitoring/simulation capabilities. Actual network slicing requires router-level QoS configuration. Always test configurations in a non-production environment first.

