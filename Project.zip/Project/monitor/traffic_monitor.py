"""
Traffic Monitor
Monitors network traffic and assigns it to appropriate slices.
"""

import time
import psutil
from typing import Dict, List, Optional
from datetime import datetime
from collections import defaultdict
from network_slicing.models import TrafficFlow, SliceType, Slice
from network_slicing.config import NetworkSlicingConfig
from monitor.classifier import TrafficClassifier


class TrafficMonitor:
    """Monitors network traffic and classifies it into slices."""
    
    def __init__(self, interface_name: Optional[str] = None):
        """
        Initialize the traffic monitor.
        
        Args:
            interface_name: Specific network interface to monitor (None = all interfaces)
        """
        self.interface_name = interface_name
        self.classifier = TrafficClassifier()
        self.config = NetworkSlicingConfig()
        
        # Track active flows
        self.active_flows: Dict[str, TrafficFlow] = {}
        self.slice_stats: Dict[SliceType, Slice] = {}
        
        # Initialize slices
        for slice_key, slice_config in self.config.get_all_slices().items():
            slice_type = SliceType(slice_key)
            self.slice_stats[slice_type] = Slice(
                name=slice_config.name,
                slice_type=slice_type,
                priority=slice_config.priority,
                bandwidth_percent=slice_config.bandwidth_percent
            )
        
        # Previous network stats for calculating deltas
        self.prev_net_io = None
        self.prev_time = None
    
    def get_network_interfaces(self) -> List[str]:
        """
        Get list of available network interfaces.
        
        Returns:
            List of interface names
        """
        interfaces = []
        net_if_addrs = psutil.net_if_addrs()
        for interface_name in net_if_addrs.keys():
            # Filter out loopback and virtual interfaces on Windows
            if not interface_name.startswith('Loopback') and 'VirtualBox' not in interface_name:
                interfaces.append(interface_name)
        return interfaces
    
    def get_interface_stats(self, interface_name: Optional[str] = None) -> Dict:
        """
        Get statistics for a network interface.
        
        Args:
            interface_name: Interface name (None = default interface)
            
        Returns:
            Dictionary with interface statistics
        """
        net_io_counters = psutil.net_io_counters(pernic=True)
        
        if interface_name:
            if interface_name in net_io_counters:
                stats = net_io_counters[interface_name]
                return {
                    'bytes_sent': stats.bytes_sent,
                    'bytes_recv': stats.bytes_recv,
                    'packets_sent': stats.packets_sent,
                    'packets_recv': stats.packets_recv,
                    'errin': stats.errin,
                    'errout': stats.errout,
                    'dropin': stats.dropin,
                    'dropout': stats.dropout
                }
        else:
            # Aggregate all interfaces
            total = psutil.net_io_counters()
            return {
                'bytes_sent': total.bytes_sent,
                'bytes_recv': total.bytes_recv,
                'packets_sent': total.packets_sent,
                'packets_recv': total.packets_recv,
                'errin': total.errin,
                'errout': total.errout,
                'dropin': total.dropin,
                'dropout': total.dropout
            }
        
        return {}
    
    def get_active_connections(self) -> List[Dict]:
        """
        Get active network connections.
        
        Returns:
            List of connection dictionaries
        """
        connections = []
        try:
            for conn in psutil.net_connections(kind='inet'):
                if conn.status == 'ESTABLISHED':
                    connections.append({
                        'fd': conn.fd,
                        'family': str(conn.family),
                        'type': str(conn.type),
                        'laddr': f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else None,
                        'raddr': f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else None,
                        'status': conn.status,
                        'pid': conn.pid
                    })
        except (psutil.AccessDenied, PermissionError):
            # On Windows, may need admin privileges
            pass
        
        return connections
    
    def get_process_network_usage(self) -> Dict[int, Dict]:
        """
        Get network usage per process.
        
        Returns:
            Dictionary mapping PID to network usage info
        """
        process_usage = {}
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'connections']):
                try:
                    pid = proc.info['pid']
                    name = proc.info['name']
                    connections = proc.info['connections'] or []
                    
                    if connections:
                        process_usage[pid] = {
                            'name': name,
                            'connections': len(connections),
                            'ports': set()
                        }
                        
                        for conn in connections:
                            if conn.laddr:
                                process_usage[pid]['ports'].add(conn.laddr.port)
                            if conn.raddr:
                                process_usage[pid]['ports'].add(conn.raddr.port)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            pass
        
        return process_usage
    
    def classify_process_traffic(self, process_name: str, port: Optional[int] = None) -> SliceType:
        """
        Classify traffic from a process.
        
        Args:
            process_name: Process name
            port: Optional port number
            
        Returns:
            SliceType for the process
        """
        # Try application name first
        slice_type = self.classifier.classify_by_application(process_name)
        
        # If port is provided and we got normal, try port-based classification
        if slice_type == SliceType.NORMAL and port:
            port_slice = self.classifier.classify_by_port(port)
            if port_slice != SliceType.NORMAL:
                return port_slice
        
        return slice_type
    
    def calculate_bandwidth_usage(self, duration_seconds: float = 1.0) -> Dict[SliceType, float]:
        """
        Calculate current bandwidth usage per slice.
        
        Args:
            duration_seconds: Duration to measure over
            
        Returns:
            Dictionary mapping SliceType to bandwidth in Mbps
        """
        # Get initial stats
        initial_stats = self.get_interface_stats(self.interface_name)
        initial_time = time.time()
        
        time.sleep(duration_seconds)
        
        # Get final stats
        final_stats = self.get_interface_stats(self.interface_name)
        final_time = time.time()
        
        # Calculate deltas
        bytes_sent_delta = final_stats.get('bytes_sent', 0) - initial_stats.get('bytes_sent', 0)
        bytes_recv_delta = final_stats.get('bytes_recv', 0) - initial_stats.get('bytes_recv', 0)
        total_bytes = bytes_sent_delta + bytes_recv_delta
        
        elapsed = final_time - initial_time
        if elapsed > 0:
            bandwidth_mbps = (total_bytes * 8) / (elapsed * 1_000_000)  # Convert to Mbps
        else:
            bandwidth_mbps = 0.0
        
        # For now, return total bandwidth (in real implementation, would be per-slice)
        return {SliceType.NORMAL: bandwidth_mbps}
    
    def update_slice_statistics(self):
        """Update statistics for each slice."""
        process_usage = self.get_process_network_usage()
        
        # Reset slice counters
        for slice_obj in self.slice_stats.values():
            slice_obj.active_flows = 0
            slice_obj.current_bandwidth_usage = 0.0
        
        # Classify processes and update slices
        for pid, proc_info in process_usage.items():
            process_name = proc_info['name']
            ports = proc_info.get('ports', set())
            
            # Classify this process
            slice_type = SliceType.NORMAL
            if ports:
                # Use first port for classification
                port = next(iter(ports))
                slice_type = self.classify_process_traffic(process_name, port)
            else:
                slice_type = self.classify_process_traffic(process_name)
            
            # Update slice statistics
            if slice_type in self.slice_stats:
                self.slice_stats[slice_type].active_flows += 1
    
    def get_slice_statistics(self) -> Dict[SliceType, Slice]:
        """
        Get current statistics for all slices.
        
        Returns:
            Dictionary mapping SliceType to Slice objects
        """
        self.update_slice_statistics()
        return self.slice_stats.copy()

