# DD-WRT QoS Configuration for Network Slicing
# Apply via: Administration -> Commands -> Run Commands

# Enable QoS
nvram set qos_enable=1
nvram set qos_classnames="Priority Normal Background"

# Set total bandwidth
nvram set qos_ibw=100
nvram set qos_obw=100

# Priority Slice (50% bandwidth)
nvram set qos_orules="<Priority> <443> <0> <50> <0> <0> <0> <0>"

# Normal Slice (35% bandwidth)
nvram set qos_orules="$qos_orules <Normal> <80> <0> <35> <0> <0> <0> <0>"

# Background Slice (15% bandwidth)
nvram set qos_orules="$qos_orules <Background> <21> <0> <15> <0> <0> <0> <0>"

# Commit and restart QoS
nvram commit
stopservice qos
startservice qos